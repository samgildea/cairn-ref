import type { LinearIssueVM } from './protocol';

// ---------------------------------------------------------------------------
// PR body handling. Pure.

const LINE = /^[ \t]*Linear:[ \t]*(.*?)[ \t]*$/im;
const ISSUE_URL = /https:\/\/linear\.app\/[^\s/)]+\/issue\/([A-Z][A-Z0-9]*-\d+)[^\s)>\]]*/i;

export type BodyLink =
	| { kind: 'issue'; url?: string; identifier: string }
	| { kind: 'none' }
	| null;

/** Finds the Linear link a PR body already carries: a `Linear:` line first, then any linear.app issue URL. */
export function extractLinearLink(body: string | undefined): BodyLink {
	if (!body) {
		return null;
	}
	const line = LINE.exec(body);
	if (line) {
		const value = line[1];
		if (/^none$/i.test(value)) {
			return { kind: 'none' };
		}
		const url = ISSUE_URL.exec(value);
		if (url) {
			return { kind: 'issue', url: url[0], identifier: url[1].toUpperCase() };
		}
		const id = /^([A-Z][A-Z0-9]*-\d+)$/i.exec(value);
		if (id) {
			return { kind: 'issue', identifier: id[1].toUpperCase() };
		}
	}
	const any = ISSUE_URL.exec(body);
	if (any) {
		return { kind: 'issue', url: any[0], identifier: any[1].toUpperCase() };
	}
	return null;
}

/**
 * Returns the body with exactly one `Linear:` line: `Linear: <url>` when an
 * issue is attached, `Linear: none` when the user cleared it. `undefined`
 * leaves the body as it is.
 */
export function withLinearLine(body: string, issueUrl: string | null | undefined): string {
	if (issueUrl === undefined) {
		return body;
	}
	const line = `Linear: ${issueUrl ?? 'none'}`;
	const isLinearLine = (l: string) => /^[ \t]*Linear:/i.test(l);
	const out: string[] = [];
	let placed = false;
	for (const l of body.split('\n')) {
		if (!isLinearLine(l)) {
			out.push(l);
		} else if (!placed) {
			out.push(line);
			placed = true;
		}
	}
	if (placed) {
		return out.join('\n');
	}
	const trimmed = body.replace(/\s+$/, '');
	return trimmed ? `${trimmed}\n\n${line}` : line;
}

// ---------------------------------------------------------------------------
// Read-only client. Search, one issue, and sub-issues. Nothing that writes.

export interface LinearAuth {
	/** value for the Authorization header */
	header: string;
	source: 'vscode-session' | 'secret' | 'env';
}

export class LinearAuthError extends Error {}

const ISSUE_FIELDS = 'id identifier title url branchName state { name type }';

type IssueNode = {
	id: string;
	identifier: string;
	title: string;
	url: string;
	branchName?: string;
	state?: { name?: string; type?: string };
};

function toVM(n: IssueNode): LinearIssueVM {
	return {
		id: n.id,
		identifier: n.identifier,
		title: n.title,
		url: n.url,
		branchName: n.branchName || undefined,
		state: n.state?.name ?? '',
		stateType: n.state?.type ?? '',
	};
}

export class LinearClient {
	private readonly issueCache = new Map<string, LinearIssueVM>();

	constructor(private readonly auth: () => Promise<LinearAuth | null>, private readonly endpoint = 'https://api.linear.app/graphql') {}

	private async query<T>(query: string, variables: Record<string, unknown>): Promise<T> {
		const auth = await this.auth();
		if (!auth) {
			throw new LinearAuthError('Linear is not connected');
		}
		const res = await fetch(this.endpoint, {
			method: 'POST',
			headers: { 'content-type': 'application/json', authorization: auth.header },
			body: JSON.stringify({ query, variables }),
		});
		if (res.status === 401 || res.status === 403) {
			throw new LinearAuthError(`Linear rejected the credentials (${res.status})`);
		}
		const json = (await res.json()) as { data?: T; errors?: Array<{ message: string }> };
		if (json.errors?.length) {
			throw new Error(json.errors.map(e => e.message).join('; '));
		}
		if (!json.data) {
			throw new Error(`Linear returned HTTP ${res.status} with no data`);
		}
		return json.data;
	}

	cached(identifier: string): LinearIssueVM | undefined {
		return this.issueCache.get(identifier.toUpperCase());
	}

	private remember(issue: LinearIssueVM): LinearIssueVM {
		this.issueCache.set(issue.identifier.toUpperCase(), issue);
		return issue;
	}

	async search(term: string): Promise<LinearIssueVM[]> {
		const data = await this.query<{ searchIssues: { nodes: IssueNode[] } }>(
			`query($term: String!) { searchIssues(term: $term, first: 20) { nodes { ${ISSUE_FIELDS} } } }`,
			{ term },
		);
		return data.searchIssues.nodes.map(n => this.remember(toVM(n)));
	}

	async recent(): Promise<LinearIssueVM[]> {
		const data = await this.query<{ viewer: { assignedIssues: { nodes: IssueNode[] } } }>(
			`query { viewer { assignedIssues(first: 20, orderBy: updatedAt, filter: { state: { type: { nin: ["completed", "canceled"] } } }) { nodes { ${ISSUE_FIELDS} } } } }`,
			{},
		);
		return data.viewer.assignedIssues.nodes.map(n => this.remember(toVM(n)));
	}

	/** Accepts an id or an identifier like ENG-123. */
	async issue(idOrIdentifier: string): Promise<LinearIssueVM | null> {
		const data = await this.query<{ issue: IssueNode | null }>(
			`query($id: String!) { issue(id: $id) { ${ISSUE_FIELDS} } }`,
			{ id: idOrIdentifier },
		);
		return data.issue ? this.remember(toVM(data.issue)) : null;
	}

	/** Sub-issues in Linear's own sort order. The caller asks the user to confirm the stack order. */
	async children(parentId: string): Promise<LinearIssueVM[]> {
		const data = await this.query<{ issue: { children: { nodes: IssueNode[] } } | null }>(
			`query($id: String!) { issue(id: $id) { children(first: 50) { nodes { ${ISSUE_FIELDS} } } } }`,
			{ id: parentId },
		);
		return (data.issue?.children.nodes ?? []).map(n => this.remember(toVM(n)));
	}
}
