import { describe, expect, it } from 'vitest';
import { extractLinearLink, withLinearLine } from '../src/linear';

const URL = 'https://linear.app/acme/issue/ENG-42/add-auth-middleware';

describe('extractLinearLink', () => {
	it('reads a Linear: line', () => {
		expect(extractLinearLink(`Adds auth.\n\nLinear: ${URL}`)).toEqual({ kind: 'issue', url: URL, identifier: 'ENG-42' });
		expect(extractLinearLink('Linear: eng-7')).toEqual({ kind: 'issue', identifier: 'ENG-7' });
		expect(extractLinearLink('body\nLinear: none\n')).toEqual({ kind: 'none' });
	});

	it('falls back to any linear.app issue URL in the body', () => {
		expect(extractLinearLink(`Fixes [ENG-42](${URL}).`)).toEqual({ kind: 'issue', url: URL, identifier: 'ENG-42' });
	});

	it('returns null when there is no link', () => {
		expect(extractLinearLink('Just a body')).toBeNull();
		expect(extractLinearLink(undefined)).toBeNull();
	});
});

describe('withLinearLine', () => {
	it('appends the line when absent', () => {
		expect(withLinearLine('Adds auth.', URL)).toBe(`Adds auth.\n\nLinear: ${URL}`);
		expect(withLinearLine('', URL)).toBe(`Linear: ${URL}`);
	});

	it('replaces an existing line in place and removes duplicates', () => {
		expect(withLinearLine('a\nLinear: https://linear.app/acme/issue/ENG-1/x\nb\nLinear: none', URL)).toBe(`a\nLinear: ${URL}\nb`);
	});

	it('writes Linear: none when the user cleared the issue', () => {
		expect(withLinearLine(`a\n\nLinear: ${URL}`, null)).toBe('a\n\nLinear: none');
	});

	it('leaves the body alone when nothing was decided', () => {
		expect(withLinearLine('a', undefined)).toBe('a');
	});
});
