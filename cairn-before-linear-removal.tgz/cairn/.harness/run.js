"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// scripts/harness/run.ts
var import_node_child_process = require("node:child_process");
var import_node_fs3 = require("node:fs");

// src/controller.ts
var path3 = __toESM(require("node:path"));
var import_node_crypto2 = require("node:crypto");

// scripts/harness/vscode-stub.ts
var prompts = [];
var opened = [];
var Emitter = class {
  listeners = [];
  event = (fn) => {
    this.listeners.push(fn);
    return { dispose: () => this.listeners = this.listeners.filter((l) => l !== fn) };
  };
  fire(e) {
    this.listeners.forEach((l) => l(e));
  }
};
var Uri = class _Uri {
  constructor(scheme, fsPath) {
    this.scheme = scheme;
    this.fsPath = fsPath;
  }
  scheme;
  fsPath;
  static file(p) {
    return new _Uri("file", p);
  }
  static parse(s) {
    return new _Uri("https", s);
  }
  static joinPath(u, ...parts) {
    return new _Uri(u.scheme, [u.fsPath, ...parts].join("/"));
  }
  toString() {
    return `${this.scheme}://${this.fsPath}`;
  }
};
var RelativePattern = class {
  constructor(base, pattern) {
    this.base = base;
    this.pattern = pattern;
  }
  base;
  pattern;
};
var config = {};
var noop = { dispose() {
} };
var workspace = {
  workspaceFolders: [],
  getConfiguration: () => ({ get: (k) => config[k] }),
  getWorkspaceFolder: () => void 0,
  createFileSystemWatcher: () => ({ onDidChange: () => noop, onDidCreate: () => noop, onDidDelete: () => noop, dispose() {
  } }),
  onDidChangeWorkspaceFolders: () => noop,
  onDidSaveTextDocument: () => noop,
  onDidChangeConfiguration: () => noop
};
function record(kind) {
  return async (message, ...rest) => {
    const opts = rest.find((r) => typeof r === "object" && r !== null);
    const actions = rest.filter((r) => typeof r === "string");
    prompts.push({ kind, message, detail: opts?.detail });
    return opts?.modal ? actions[0] : void 0;
  };
}
var window = {
  activeTextEditor: void 0,
  onDidChangeWindowState: () => noop,
  showInformationMessage: record("info"),
  showWarningMessage: record("warning"),
  showErrorMessage: record("error"),
  showQuickPick: async () => void 0,
  showInputBox: async () => void 0,
  createQuickPick: () => {
    throw new Error("quick pick not available in the harness");
  }
};
var authentication = {
  onDidChangeSessions: () => noop,
  getSession: async () => void 0
};
var commands = {
  executeCommand: async (id, ...args) => {
    opened.push(`${id} ${args.map((a) => String(a)).join(" ")}`);
  }
};
var env = {
  openExternal: async (u) => {
    opened.push(`openExternal ${u.fsPath}`);
    return true;
  }
};
var extensions = { getExtension: () => void 0 };
function memento() {
  const store = /* @__PURE__ */ new Map();
  return {
    get: (k, d) => store.has(k) ? store.get(k) : d,
    update: async (k, v) => {
      if (v === void 0) {
        store.delete(k);
      } else {
        store.set(k, v);
      }
    },
    keys: () => [...store.keys()]
  };
}
function fakeWebviewView() {
  const fromWebview = new Emitter();
  const posted = [];
  const view = {
    visible: true,
    webview: {
      options: {},
      html: "",
      cspSource: "vscode-resource:",
      asWebviewUri: (u) => u,
      postMessage: async (m) => {
        posted.push(m);
        return true;
      },
      onDidReceiveMessage: (fn) => fromWebview.event(fn)
    },
    onDidChangeVisibility: () => noop
  };
  return { view, posted, send: (m) => fromWebview.fire(m) };
}

// src/git.ts
var import_node_fs2 = require("node:fs");
var path2 = __toESM(require("node:path"));

// src/metadata.ts
var import_node_crypto = require("node:crypto");
var import_node_fs = require("node:fs");
var path = __toESM(require("node:path"));
var STACK_FILE = "gh-stack";
var SUPPORTED_SCHEMA_VERSION = 1;
var GH_STACK_JOURNALS = ["gh-stack-rebase-state", "gh-stack-modify-state", "gh-stack-migration"];
var MetadataError = class extends Error {
  constructor(message, code) {
    super(message);
    this.code = code;
  }
  code;
};
function stackFilePath(commonDir) {
  return path.join(commonDir, STACK_FILE);
}
function checksumOf(bytes) {
  return bytes === null ? "absent" : (0, import_node_crypto.createHash)("sha256").update(bytes).digest("hex");
}
async function snapshotStackFile(commonDir) {
  const p = stackFilePath(commonDir);
  let bytes = null;
  try {
    bytes = await import_node_fs.promises.readFile(p);
  } catch (e) {
    if (e.code !== "ENOENT") {
      throw new MetadataError(`could not read ${p}: ${e.message}`, "io");
    }
  }
  return { path: p, bytes, checksum: checksumOf(bytes) };
}
function parseCatalog(bytes) {
  let json;
  try {
    json = JSON.parse(bytes.toString());
  } catch (e) {
    throw new MetadataError(`gh-stack file is not valid JSON: ${e.message}`, "parse");
  }
  if (typeof json !== "object" || json === null || Array.isArray(json)) {
    throw new MetadataError("gh-stack file is not a JSON object", "parse");
  }
  const obj = json;
  if (obj.schemaVersion !== SUPPORTED_SCHEMA_VERSION) {
    throw new MetadataError(
      `gh-stack file has schemaVersion ${JSON.stringify(obj.schemaVersion)}; this extension only writes version ${SUPPORTED_SCHEMA_VERSION}. Nothing was changed.`,
      "schema"
    );
  }
  if (!Array.isArray(obj.stacks)) {
    throw new MetadataError("gh-stack file has no stacks array", "parse");
  }
  return obj;
}
function asObject(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v) ? v : null;
}
function listCatalogStacks(catalog) {
  const stacks = catalog.stacks;
  return stacks.flatMap((s, index) => {
    const o = asObject(s);
    const trunk = asObject(o?.trunk);
    if (!o || !trunk || typeof trunk.branch !== "string" || !Array.isArray(o.branches)) {
      return [];
    }
    const branches = o.branches.flatMap((b) => {
      const bo = asObject(b);
      if (!bo || typeof bo.branch !== "string") {
        return [];
      }
      const pr = asObject(bo.pullRequest);
      return [{
        branch: bo.branch,
        base: typeof bo.base === "string" ? bo.base : void 0,
        head: typeof bo.head === "string" ? bo.head : void 0,
        prNumber: typeof pr?.number === "number" ? pr.number : void 0
      }];
    });
    return [{
      index,
      number: typeof o.number === "number" && o.number > 0 ? o.number : void 0,
      trunk: trunk.branch,
      trunkHead: typeof trunk.head === "string" ? trunk.head : void 0,
      branches
    }];
  });
}
function findStackIndex(catalog, trunk, branches) {
  const stacks = listCatalogStacks(catalog);
  const exact = stacks.find((s) => s.trunk === trunk && s.branches.map((b) => b.branch).join("\n") === branches.join("\n"));
  if (exact) {
    return exact.index;
  }
  const overlap = stacks.filter((s) => s.trunk === trunk && s.branches.some((b) => branches.includes(b.branch)));
  if (overlap.length === 1) {
    return overlap[0].index;
  }
  throw new MetadataError(`could not find exactly one stack in the gh-stack file for ${trunk} \u2190 ${branches.join(" \u2190 ")}`, "not-found");
}
function rewriteStack(catalog, stackIndex, entries) {
  const stacks = catalog.stacks;
  const target = asObject(stacks[stackIndex]);
  if (!target || !Array.isArray(target.branches)) {
    throw new MetadataError(`stack #${stackIndex} is missing from the gh-stack file`, "not-found");
  }
  const existing = /* @__PURE__ */ new Map();
  for (const b of target.branches) {
    const bo = asObject(b);
    if (bo && typeof bo.branch === "string") {
      existing.set(bo.branch, bo);
    }
  }
  const branches = entries.map((e) => {
    const prev = existing.get(e.branch);
    const next = prev ? { ...prev } : { branch: e.branch };
    next.base = e.base;
    if (prev && "head" in prev && e.head) {
      next.head = e.head;
    }
    return next;
  });
  const nextStacks = stacks.slice();
  nextStacks[stackIndex] = { ...target, branches };
  return { ...catalog, stacks: nextStacks };
}
function serializeCatalog(catalog) {
  return JSON.stringify(catalog, null, 2);
}
var LOCKED_WRITE = String.raw`
use strict; use warnings;
use Fcntl qw(:flock O_RDWR O_CREAT);
use Digest::SHA qw(sha256_hex);
use File::Temp qw(tempfile);
my ($dir, $expect, $mode) = @ARGV;
sub take { my $p = shift; sysopen(my $fh, $p, O_RDWR|O_CREAT, 0644) or die "open $p: $!\n";
  my $deadline = time + 5;
  until (flock($fh, LOCK_EX|LOCK_NB)) { if (time > $deadline) { print STDERR "timed out waiting for $p\n"; exit 8 } select(undef, undef, undef, 0.1) }
  return $fh }
my $op = take("$dir/gh-stack-operation.lock");
my $cat = take("$dir/gh-stack.lock");
my $path = "$dir/gh-stack";
if ($expect ne '-') {
  my $cur = 'absent';
  if (-e $path) { open(my $r, '<:raw', $path) or die "read $path: $!\n"; local $/; my $d = <$r>; $cur = sha256_hex(defined $d ? $d : '') }
  if ($cur ne $expect) { print STDERR "gh-stack file changed on disk since it was read\n"; exit 9 }
}
if ($mode eq 'delete') { unlink $path if -e $path; exit 0 }
binmode STDIN; local $/; my $data = <STDIN>; $data = '' unless defined $data;
my $perm = (-e $path) ? ((stat $path)[2] & 07777) : 0644;
my ($fh, $tmp) = tempfile('.gh-stack-cairn-XXXXXX', DIR => $dir);
binmode $fh; print $fh $data or die "write: $!\n"; close $fh or die "close: $!\n";
chmod $perm, $tmp; rename($tmp, $path) or die "rename: $!\n";
exit 0;
`;
async function writeStackFileLocked(opts) {
  const { run: run2, commonDir, expectedChecksum, data } = opts;
  const mode = data === null ? "delete" : "write";
  let r;
  try {
    r = await run2("perl", ["-e", LOCKED_WRITE, commonDir, expectedChecksum, mode], {
      cwd: commonDir,
      input: data === null ? "" : data.toString(),
      label: `${mode === "delete" ? "remove" : "write"} ${stackFilePath(commonDir)} (holding gh-stack locks)`
    });
  } catch {
    await writeUnlocked(commonDir, expectedChecksum, data);
    return;
  }
  if (r.code === 8) {
    throw new MetadataError("the gh-stack file is locked by another gh stack process; try again in a few seconds", "locked");
  }
  if (r.code === 9) {
    throw new MetadataError("the gh-stack file changed while the plan ran; nothing was written", "stale");
  }
  if (r.code !== 0) {
    throw new MetadataError(`writing the gh-stack file failed: ${r.stderr.trim()}`, "io");
  }
}
async function writeUnlocked(commonDir, expectedChecksum, data) {
  const p = stackFilePath(commonDir);
  if (expectedChecksum !== "-") {
    const now = await snapshotStackFile(commonDir);
    if (now.checksum !== expectedChecksum) {
      throw new MetadataError("the gh-stack file changed while the plan ran; nothing was written", "stale");
    }
  }
  if (data === null) {
    await import_node_fs.promises.rm(p, { force: true });
    return;
  }
  const tmp = path.join(commonDir, `.gh-stack-cairn-${process.pid}-${Date.now()}`);
  await import_node_fs.promises.writeFile(tmp, data);
  await import_node_fs.promises.rename(tmp, p);
}

// src/git.ts
var GitError = class extends Error {
  constructor(args, code, stderr) {
    super(`git ${args.join(" ")} exited ${code}: ${stderr.trim()}`);
    this.args = args;
    this.code = code;
    this.stderr = stderr;
  }
  args;
  code;
  stderr;
};
var Git = class {
  constructor(run2, cwd) {
    this.run = run2;
    this.cwd = cwd;
  }
  run;
  cwd;
  async raw(args, opts = {}) {
    return this.run("git", args, { cwd: this.cwd, quiet: opts.quiet ?? true, env: opts.env });
  }
  async ok(args, opts = {}) {
    const r = await this.raw(args, opts);
    if (r.code !== 0) {
      throw new GitError(args, r.code, r.stderr);
    }
    return r.stdout;
  }
  async dirs() {
    const out = await this.ok(["rev-parse", "--show-toplevel", "--absolute-git-dir", "--git-common-dir"]);
    const [topLevel, gitDir, common] = out.split("\n").map((s) => s.trim());
    return { topLevel, gitDir, commonDir: path2.resolve(this.cwd, common) };
  }
  async currentBranch() {
    const r = await this.raw(["symbolic-ref", "--quiet", "--short", "HEAD"]);
    return r.code === 0 ? r.stdout.trim() : null;
  }
  async revParse(ref) {
    const r = await this.raw(["rev-parse", "--verify", "--quiet", `${ref}^{commit}`]);
    return r.code === 0 ? r.stdout.trim() : null;
  }
  async isAncestor(a, b) {
    const r = await this.raw(["merge-base", "--is-ancestor", a, b]);
    return r.code === 0;
  }
  async mergeBase(a, b) {
    const r = await this.raw(["merge-base", a, b]);
    return r.code === 0 ? r.stdout.trim() : null;
  }
  async status() {
    const out = await this.ok(["status", "--porcelain=v1", "-z", "--untracked-files=all"]);
    const tracked = [];
    const untracked = [];
    const unmerged = [];
    const parts = out.split("\0");
    for (let i = 0; i < parts.length; i++) {
      const entry = parts[i];
      if (entry.length < 4) {
        continue;
      }
      const xy = entry.slice(0, 2);
      const file = entry.slice(3);
      if (xy === "??") {
        untracked.push(file);
        continue;
      }
      if (xy === "!!") {
        continue;
      }
      if (xy.includes("U") || xy === "AA" || xy === "DD") {
        unmerged.push(file);
      }
      tracked.push(file);
      if (xy[0] === "R" || xy[0] === "C") {
        i++;
      }
    }
    return { tracked, untracked, unmerged };
  }
  async unmergedFiles() {
    const out = await this.ok(["diff", "--name-only", "--diff-filter=U", "-z"]);
    return out.split("\0").filter(Boolean);
  }
  /** One read of refs/heads with upstream tracking from local refs/remotes. No network. */
  async branchRefs() {
    const out = await this.ok([
      "for-each-ref",
      "--format=%(refname:short)%00%(objectname)%00%(upstream:short)%00%(upstream:track,nobracket)",
      "refs/heads"
    ]);
    const map = /* @__PURE__ */ new Map();
    for (const line of out.split("\n")) {
      if (!line) {
        continue;
      }
      const [name, sha, upstream, trackText] = line.split("\0");
      map.set(name, { sha, track: parseTrack(upstream, trackText) });
    }
    return map;
  }
  async localBranchesNotMergedInto(trunk) {
    const out = await this.ok(["for-each-ref", "--format=%(refname:short)", `--no-merged=${trunk}`, "refs/heads"]);
    return out.split("\n").filter((n) => n && n !== trunk);
  }
  async log(base, head, limit = 200) {
    const out = await this.ok(["log", `--max-count=${limit}`, "--format=%H%x00%h%x00%s", `${base}..${head}`]);
    return out.split("\n").filter(Boolean).map((l) => {
      const [sha, short, subject] = l.split("\0");
      return { sha, short, subject };
    });
  }
  async numstat(base, head) {
    const out = await this.ok(["diff", "--numstat", "-z", "--no-renames", `${base}...${head}`]);
    return parseNumstatZ(out);
  }
  async commitMessage(sha) {
    const out = await this.ok(["show", "-s", "--format=%s%x00%b", sha]);
    const [subject, body = ""] = out.split("\0");
    return { subject: subject.trim(), body: body.trim() };
  }
  async defaultTrunk() {
    const r = await this.raw(["symbolic-ref", "--quiet", "--short", "refs/remotes/origin/HEAD"]);
    if (r.code === 0) {
      return r.stdout.trim().replace(/^origin\//, "");
    }
    for (const name of ["main", "master", "trunk", "develop"]) {
      if (await this.revParse(`refs/heads/${name}`)) {
        return name;
      }
    }
    return null;
  }
};
function parseTrack(upstream, trackText) {
  const t = trackText ?? "";
  return {
    upstream: upstream || void 0,
    ahead: Number(/ahead (\d+)/.exec(t)?.[1] ?? 0),
    behind: Number(/behind (\d+)/.exec(t)?.[1] ?? 0),
    gone: t.includes("gone")
  };
}
function parseNumstatZ(out) {
  const files = [];
  for (const rec of out.split("\0")) {
    if (!rec) {
      continue;
    }
    const m = /^(-|\d+)\t(-|\d+)\t(.*)$/s.exec(rec);
    if (!m) {
      continue;
    }
    files.push({
      path: m[3].replace(/^\n/, ""),
      additions: m[1] === "-" ? null : Number(m[1]),
      deletions: m[2] === "-" ? null : Number(m[2])
    });
  }
  return files;
}
async function exists(p) {
  try {
    await import_node_fs2.promises.access(p);
    return true;
  } catch {
    return false;
  }
}
async function rebaseState(dirs) {
  for (const journal of GH_STACK_JOURNALS) {
    for (const dir of /* @__PURE__ */ new Set([dirs.commonDir, dirs.gitDir])) {
      if (await exists(path2.join(dir, journal))) {
        return { kind: "gh-stack", journal };
      }
    }
  }
  if (await exists(path2.join(dirs.gitDir, "rebase-merge")) || await exists(path2.join(dirs.gitDir, "rebase-apply"))) {
    return { kind: "git" };
  }
  return { kind: "none" };
}
async function lastFetchTime(dirs) {
  for (const dir of /* @__PURE__ */ new Set([dirs.gitDir, dirs.commonDir])) {
    try {
      return (await import_node_fs2.promises.stat(path2.join(dir, "FETCH_HEAD"))).mtimeMs;
    } catch {
    }
  }
  return null;
}
function humanizeBranch(name) {
  return name.replace(/[-_]/g, " ");
}

// src/apply.ts
var REBASE_ENV = { GIT_EDITOR: "true", GIT_SEQUENCE_EDITOR: "true" };
var ApplyEngine = class {
  constructor(run2, dirs, store) {
    this.run = run2;
    this.dirs = dirs;
    this.store = store;
    this.git = new Git(run2, dirs.topLevel);
  }
  run;
  dirs;
  store;
  git;
  get session() {
    const s = this.store.get();
    return s && s.commonDir === this.dirs.commonDir ? s : void 0;
  }
  get inFlight() {
    const s = this.session;
    return !!s && (s.phase === "running" || s.phase === "conflict");
  }
  async start(plan, ctx) {
    if (this.inFlight) {
      return { kind: "failed", message: "an apply is already in flight", restored: false };
    }
    const refs = {};
    for (const b of /* @__PURE__ */ new Set([...ctx.branches, ...plan.metadata.order.map((o) => o.branch)])) {
      const sha = await this.git.revParse(`refs/heads/${b}`);
      if (!sha) {
        return { kind: "failed", message: `branch ${b} does not exist`, restored: false };
      }
      refs[b] = sha;
    }
    const file = await snapshotStackFile(this.dirs.commonDir);
    if (file.bytes) {
      parseCatalog(file.bytes);
    }
    const snapshot = {
      refs,
      originalBranch: await this.git.currentBranch(),
      originalHead: await this.git.revParse("HEAD") ?? "",
      stackFile: file.bytes ? file.bytes.toString("base64") : null
    };
    await this.store.set({
      commonDir: this.dirs.commonDir,
      snapshot,
      steps: plan.steps,
      metadata: plan.metadata,
      trunk: ctx.trunk,
      trunkTip: ctx.trunkTip,
      originalOrder: ctx.originalOrder,
      next: 0,
      phase: "running",
      published: false
    });
    return this.runSteps();
  }
  async update(patch) {
    const next = { ...this.session, ...patch };
    await this.store.set(next);
    return next;
  }
  async runSteps() {
    let s = this.session;
    while (s.next < s.steps.length) {
      const step = s.steps[s.next];
      const r = await this.git.raw(step.argv, { quiet: false, env: REBASE_ENV });
      if (r.code !== 0) {
        if ((await rebaseState(this.dirs)).kind === "git") {
          await this.update({ phase: "conflict" });
          return { kind: "conflict", branch: step.branch, step: s.next + 1, total: s.steps.length, files: await this.git.unmergedFiles() };
        }
        return this.failAndRestore(`git ${step.argv.join(" ")} failed: ${r.stderr.trim()}`);
      }
      s = await this.update({ next: s.next + 1, phase: "running" });
    }
    try {
      await this.writeMetadata(s);
    } catch (e) {
      return this.failAndRestore(e.message);
    }
    if (s.snapshot.originalBranch) {
      await this.git.raw(["checkout", "--quiet", s.snapshot.originalBranch], { quiet: false });
    }
    const postRefs = {};
    for (const b of Object.keys(s.snapshot.refs)) {
      postRefs[b] = await this.git.revParse(`refs/heads/${b}`) ?? "";
    }
    await this.update({ phase: "applied", postRefs });
    return { kind: "applied" };
  }
  async writeMetadata(s) {
    const file = await snapshotStackFile(this.dirs.commonDir);
    if (!file.bytes) {
      throw new Error("the gh-stack file disappeared while the plan ran");
    }
    const catalog = parseCatalog(file.bytes);
    const index = findStackIndex(catalog, s.trunk, s.originalOrder);
    const entries = [];
    for (const o of s.metadata.order) {
      const head = await this.git.revParse(`refs/heads/${o.branch}`);
      if (!head) {
        throw new Error(`branch ${o.branch} vanished while the plan ran`);
      }
      let base;
      if (o.base.kind === "keep") {
        base = o.base.sha;
      } else if (o.base.parent === null) {
        base = s.trunkTip;
      } else {
        const parentTip = await this.git.revParse(`refs/heads/${o.base.parent}`);
        if (!parentTip) {
          throw new Error(`branch ${o.base.parent} vanished while the plan ran`);
        }
        base = parentTip;
      }
      entries.push({ branch: o.branch, base, head });
    }
    const next = rewriteStack(catalog, index, entries);
    await writeStackFileLocked({ run: this.run, commonDir: this.dirs.commonDir, expectedChecksum: file.checksum, data: serializeCatalog(next) });
  }
  async continue() {
    const s = this.session;
    if (!s || s.phase !== "conflict") {
      return { kind: "failed", message: "no paused apply to continue", restored: false };
    }
    const unmerged = await this.git.unmergedFiles();
    if (unmerged.length > 0) {
      return { kind: "failed", message: `stage these files first: ${unmerged.join(", ")}`, restored: false };
    }
    const r = await this.git.raw(["rebase", "--continue"], { quiet: false, env: REBASE_ENV });
    if (r.code !== 0) {
      if ((await rebaseState(this.dirs)).kind === "git") {
        const step = s.steps[s.next];
        return { kind: "conflict", branch: step.branch, step: s.next + 1, total: s.steps.length, files: await this.git.unmergedFiles() };
      }
      return this.failAndRestore(`git rebase --continue failed: ${r.stderr.trim()}`);
    }
    await this.update({ next: s.next + 1, phase: "running" });
    return this.runSteps();
  }
  async abort() {
    const s = this.session;
    if (!s) {
      return;
    }
    await this.restore(s.snapshot);
    await this.store.set(void 0);
  }
  /** Why Undo is unavailable, or null when it can run. */
  async undoBlocker() {
    const s = this.session;
    if (!s || s.phase !== "applied") {
      return "nothing to undo";
    }
    if (s.published) {
      return "the result was pushed or submitted; Undo is local only";
    }
    for (const [b, sha] of Object.entries(s.postRefs ?? {})) {
      const now = await this.git.revParse(`refs/heads/${b}`);
      if (now !== sha) {
        return `${b} moved after the apply`;
      }
    }
    const st = await this.git.status();
    if (st.tracked.length > 0) {
      return "the worktree has uncommitted changes";
    }
    return null;
  }
  async undo() {
    const blocker = await this.undoBlocker();
    if (blocker) {
      throw new Error(`cannot undo: ${blocker}`);
    }
    await this.restore(this.session.snapshot);
    await this.store.set(void 0);
  }
  async markPublished() {
    if (this.session?.phase === "applied") {
      await this.update({ published: true });
    }
  }
  async dismiss() {
    if (this.session?.phase === "applied") {
      await this.store.set(void 0);
    }
  }
  async failAndRestore(message) {
    const s = this.session;
    try {
      await this.restore(s.snapshot);
      await this.store.set(void 0);
      return { kind: "failed", message, restored: true };
    } catch (e) {
      return { kind: "failed", message: `${message}; restoring the snapshot also failed: ${e.message}`, restored: false };
    }
  }
  /** Puts every branch back on its snapshot SHA and the gh-stack file back to its original bytes. */
  async restore(snapshot) {
    if ((await rebaseState(this.dirs)).kind === "git") {
      await this.git.ok(["rebase", "--abort"], { quiet: false });
    }
    await this.git.ok(["checkout", "--quiet", "--detach"], { quiet: false });
    for (const [b, sha] of Object.entries(snapshot.refs)) {
      await this.git.ok(["update-ref", `refs/heads/${b}`, sha], { quiet: false });
    }
    if (snapshot.originalBranch) {
      await this.git.ok(["checkout", "--quiet", snapshot.originalBranch], { quiet: false });
    } else {
      await this.git.ok(["checkout", "--quiet", "--detach", snapshot.originalHead], { quiet: false });
    }
    await writeStackFileLocked({
      run: this.run,
      commonDir: this.dirs.commonDir,
      expectedChecksum: "-",
      data: snapshot.stackFile === null ? null : Buffer.from(snapshot.stackFile, "base64")
    });
  }
};

// src/github.ts
var FIELDS = "number,title,body,url,isDraft,state,reviewDecision,statusCheckRollup,comments,reviews,additions,deletions,baseRefName";
var FAIL = /* @__PURE__ */ new Set(["FAILURE", "ERROR", "CANCELLED", "TIMED_OUT", "ACTION_REQUIRED", "STARTUP_FAILURE"]);
var PENDING_STATE = /* @__PURE__ */ new Set(["PENDING", "EXPECTED"]);
function summarizeRollup(items) {
  if (!items || items.length === 0) {
    return "none";
  }
  let pending = false;
  for (const it of items) {
    if (it.__typename === "StatusContext" || it.state && !it.status) {
      const s = (it.state ?? "").toUpperCase();
      if (FAIL.has(s)) {
        return "failing";
      }
      if (PENDING_STATE.has(s)) {
        pending = true;
      }
      continue;
    }
    if ((it.status ?? "").toUpperCase() !== "COMPLETED") {
      pending = true;
      continue;
    }
    if (FAIL.has((it.conclusion ?? "").toUpperCase())) {
      return "failing";
    }
  }
  return pending ? "pending" : "passing";
}
function normalizeReview(v) {
  return v === "APPROVED" || v === "CHANGES_REQUESTED" || v === "REVIEW_REQUIRED" ? v : null;
}
var PrCache = class {
  constructor(run2, gh) {
    this.run = run2;
    this.gh = gh;
  }
  run;
  gh;
  cache = /* @__PURE__ */ new Map();
  /** numbers already read (or tried) since the last forced refresh */
  attempted = /* @__PURE__ */ new Set();
  inflight = null;
  get(n) {
    return this.cache.get(n);
  }
  clear() {
    this.cache.clear();
    this.attempted.clear();
  }
  async refresh(cwd, numbers, opts) {
    if (this.inflight) {
      await this.inflight;
    }
    const todo = numbers.filter((n) => opts.force || !this.attempted.has(n));
    todo.forEach((n) => this.attempted.add(n));
    if (todo.length === 0) {
      return;
    }
    this.inflight = Promise.all(todo.map((n) => this.readOne(cwd, n))).then(() => void 0);
    try {
      await this.inflight;
    } finally {
      this.inflight = null;
    }
  }
  async readOne(cwd, n) {
    const r = await this.run(this.gh(), ["pr", "view", String(n), "--json", FIELDS], { cwd, quiet: true });
    if (r.code !== 0) {
      return;
    }
    try {
      const j = JSON.parse(r.stdout);
      const reviewsWithText = Array.isArray(j.reviews) ? j.reviews.filter((x) => (x.body ?? "").trim()).length : 0;
      this.cache.set(n, {
        number: j.number,
        title: j.title ?? "",
        body: j.body ?? "",
        url: j.url ?? "",
        isDraft: !!j.isDraft,
        state: j.state ?? "",
        reviewDecision: normalizeReview(j.reviewDecision),
        ci: summarizeRollup(j.statusCheckRollup),
        comments: (Array.isArray(j.comments) ? j.comments.length : 0) + reviewsWithText,
        additions: j.additions ?? 0,
        deletions: j.deletions ?? 0,
        baseRefName: j.baseRefName ?? ""
      });
    } catch {
    }
  }
};

// src/linear.ts
var LINE = /^[ \t]*Linear:[ \t]*(.*?)[ \t]*$/im;
var ISSUE_URL = /https:\/\/linear\.app\/[^\s/)]+\/issue\/([A-Z][A-Z0-9]*-\d+)[^\s)>\]]*/i;
function extractLinearLink(body) {
  if (!body) {
    return null;
  }
  const line = LINE.exec(body);
  if (line) {
    const value = line[1];
    if (/^none$/i.test(value)) {
      return { kind: "none" };
    }
    const url = ISSUE_URL.exec(value);
    if (url) {
      return { kind: "issue", url: url[0], identifier: url[1].toUpperCase() };
    }
    const id = /^([A-Z][A-Z0-9]*-\d+)$/i.exec(value);
    if (id) {
      return { kind: "issue", identifier: id[1].toUpperCase() };
    }
  }
  const any = ISSUE_URL.exec(body);
  if (any) {
    return { kind: "issue", url: any[0], identifier: any[1].toUpperCase() };
  }
  return null;
}
function withLinearLine(body, issueUrl) {
  if (issueUrl === void 0) {
    return body;
  }
  const line = `Linear: ${issueUrl ?? "none"}`;
  const isLinearLine = (l) => /^[ \t]*Linear:/i.test(l);
  const out = [];
  let placed = false;
  for (const l of body.split("\n")) {
    if (!isLinearLine(l)) {
      out.push(l);
    } else if (!placed) {
      out.push(line);
      placed = true;
    }
  }
  if (placed) {
    return out.join("\n");
  }
  const trimmed = body.replace(/\s+$/, "");
  return trimmed ? `${trimmed}

${line}` : line;
}
var LinearAuthError = class extends Error {
};
var ISSUE_FIELDS = "id identifier title url branchName state { name type }";
function toVM(n) {
  return {
    id: n.id,
    identifier: n.identifier,
    title: n.title,
    url: n.url,
    branchName: n.branchName || void 0,
    state: n.state?.name ?? "",
    stateType: n.state?.type ?? ""
  };
}
var LinearClient = class {
  constructor(auth, endpoint = "https://api.linear.app/graphql") {
    this.auth = auth;
    this.endpoint = endpoint;
  }
  auth;
  endpoint;
  issueCache = /* @__PURE__ */ new Map();
  async query(query, variables) {
    const auth = await this.auth();
    if (!auth) {
      throw new LinearAuthError("Linear is not connected");
    }
    const res = await fetch(this.endpoint, {
      method: "POST",
      headers: { "content-type": "application/json", authorization: auth.header },
      body: JSON.stringify({ query, variables })
    });
    if (res.status === 401 || res.status === 403) {
      throw new LinearAuthError(`Linear rejected the credentials (${res.status})`);
    }
    const json = await res.json();
    if (json.errors?.length) {
      throw new Error(json.errors.map((e) => e.message).join("; "));
    }
    if (!json.data) {
      throw new Error(`Linear returned HTTP ${res.status} with no data`);
    }
    return json.data;
  }
  cached(identifier) {
    return this.issueCache.get(identifier.toUpperCase());
  }
  remember(issue) {
    this.issueCache.set(issue.identifier.toUpperCase(), issue);
    return issue;
  }
  async search(term) {
    const data = await this.query(
      `query($term: String!) { searchIssues(term: $term, first: 20) { nodes { ${ISSUE_FIELDS} } } }`,
      { term }
    );
    return data.searchIssues.nodes.map((n) => this.remember(toVM(n)));
  }
  async recent() {
    const data = await this.query(
      `query { viewer { assignedIssues(first: 20, orderBy: updatedAt, filter: { state: { type: { nin: ["completed", "canceled"] } } }) { nodes { ${ISSUE_FIELDS} } } } }`,
      {}
    );
    return data.viewer.assignedIssues.nodes.map((n) => this.remember(toVM(n)));
  }
  /** Accepts an id or an identifier like ENG-123. */
  async issue(idOrIdentifier) {
    const data = await this.query(
      `query($id: String!) { issue(id: $id) { ${ISSUE_FIELDS} } }`,
      { id: idOrIdentifier }
    );
    return data.issue ? this.remember(toVM(data.issue)) : null;
  }
  /** Sub-issues in Linear's own sort order. The caller asks the user to confirm the stack order. */
  async children(parentId) {
    const data = await this.query(
      `query($id: String!) { issue(id: $id) { children(first: 50) { nodes { ${ISSUE_FIELDS} } } } }`,
      { id: parentId }
    );
    return (data.issue?.children.nodes ?? []).map((n) => this.remember(toVM(n)));
  }
};

// src/plan.ts
var TRUNK = /* @__PURE__ */ Symbol("trunk");
var PlanError = class extends Error {
};
var SHA = /^[0-9a-f]{40}([0-9a-f]{24})?$/;
function requireSha(value, what) {
  if (!SHA.test(value)) {
    throw new PlanError(`${what} must be a full commit SHA, got "${value}"`);
  }
}
function computePlan(input) {
  const { trunk, current, proposed } = input;
  const candidates = input.candidates ?? [];
  requireSha(trunk.tip, `trunk tip of ${trunk.name}`);
  const byName = /* @__PURE__ */ new Map();
  for (const b of [...current, ...candidates]) {
    if (byName.has(b.name) && !current.includes(b)) {
      continue;
    }
    byName.set(b.name, b);
  }
  const merged = current.filter((b) => b.isMerged).map((b) => b.name);
  if (merged.length > 0) {
    throw new PlanError(`the stack has merged branches (${merged.join(", ")}); run gh stack sync before reordering`);
  }
  const seen = /* @__PURE__ */ new Set();
  for (const name of proposed) {
    if (name === trunk.name) {
      throw new PlanError(`${trunk.name} is the trunk and cannot be a layer`);
    }
    if (seen.has(name)) {
      throw new PlanError(`${name} appears twice in the proposed order`);
    }
    seen.add(name);
    const b = byName.get(name);
    if (!b) {
      throw new PlanError(`${name} is not a local branch known to this stack`);
    }
    requireSha(b.head, `head of ${name}`);
    requireSha(b.base, `recorded base of ${name}`);
  }
  const originalParent = /* @__PURE__ */ new Map();
  current.forEach((b, i) => originalParent.set(b.name, i === 0 ? TRUNK : current[i - 1].name));
  const tipBefore = (p) => p === TRUNK ? trunk.tip : byName.get(p).head;
  const steps = [];
  const rewritten = /* @__PURE__ */ new Set();
  const order = [];
  proposed.forEach((name, i) => {
    const b = byName.get(name);
    const parent = i === 0 ? TRUNK : proposed[i - 1];
    const parentChanged = originalParent.get(name) !== parent;
    const parentRewritten = parent !== TRUNK && rewritten.has(parent);
    const alreadyOnParent = b.base === tipBefore(parent);
    const needed = parentRewritten || parentChanged && !alreadyOnParent;
    if (!needed) {
      order.push({ branch: name, base: { kind: "keep", sha: b.base } });
      return;
    }
    const onto = parent === TRUNK ? trunk.tip : parent;
    const ontoLabel = parent === TRUNK ? `${trunk.name} @ ${trunk.tip.slice(0, 7)}` : parent;
    steps.push({
      kind: "rebase",
      branch: name,
      onto,
      ontoLabel,
      upstream: b.base,
      argv: ["rebase", "--onto", onto, b.base, name]
    });
    rewritten.add(name);
    order.push({ branch: name, base: { kind: "parent-tip", parent: parent === TRUNK ? null : parent } });
  });
  const currentNames = current.map((b) => b.name);
  const added = proposed.filter((n) => !originalParent.has(n));
  const removed = currentNames.filter((n) => !seen.has(n));
  const keptCurrent = currentNames.filter((n) => seen.has(n));
  const keptProposed = proposed.filter((n) => originalParent.has(n));
  const moved = keptProposed.filter((n, i) => keptCurrent[i] !== n);
  const noop2 = steps.length === 0 && added.length === 0 && removed.length === 0 && moved.length === 0;
  return {
    steps,
    metadata: { kind: "metadata", order, added, removed },
    moved,
    added,
    removed,
    noop: noop2
  };
}
function describePlan(plan, stackFilePath2) {
  const lines = plan.steps.map((s) => ({
    kind: "rebase",
    branch: s.branch,
    command: `git ${s.argv.join(" ")}`,
    detail: `replay ${s.branch}'s own commits (after ${s.upstream.slice(0, 7)}) onto ${s.ontoLabel}`
  }));
  if (!plan.noop) {
    const chain = plan.metadata.order.map((o) => o.branch).join(" \u2190 ");
    const extra = [
      plan.metadata.added.length ? `adds ${plan.metadata.added.join(", ")}` : "",
      plan.metadata.removed.length ? `drops ${plan.metadata.removed.join(", ")} from tracking (branch kept)` : ""
    ].filter(Boolean).join("; ");
    lines.push({
      kind: "metadata",
      command: `write ${stackFilePath2}`,
      detail: `store order ${chain} and each branch's new base SHA${extra ? `; ${extra}` : ""}`
    });
  }
  return lines;
}

// src/stack.ts
var EXIT = {
  ok: 0,
  generic: 1,
  notInStack: 2,
  conflict: 3,
  api: 4,
  badArgs: 5,
  ambiguous: 6,
  rebaseActive: 7,
  locked: 8,
  stacksUnavailable: 9,
  modifyRecovery: 10
};
var EXIT_TEXT = {
  1: "generic error",
  2: "not in a stack",
  3: "rebase conflict",
  4: "GitHub API failure",
  5: "invalid arguments",
  6: "branch belongs to several stacks",
  7: "rebase already in progress",
  8: "stack file locked by another gh stack process",
  9: "stacked PRs are not enabled on this repository",
  10: "an interrupted gh stack modify session needs recovery (gh stack modify --abort)"
};
function describeExit(code) {
  return EXIT_TEXT[code] ?? `exit code ${code}`;
}
var StackParseError = class extends Error {
};
var PR_STATES = /* @__PURE__ */ new Set(["OPEN", "MERGED", "QUEUED"]);
function str(v, field) {
  if (typeof v !== "string") {
    throw new StackParseError(`expected ${field} to be a string`);
  }
  return v;
}
function optStr(v, field) {
  if (v === void 0 || v === null || v === "") {
    return void 0;
  }
  return str(v, field);
}
function bool(v) {
  return v === true;
}
function parseStackView(stdout) {
  let raw;
  try {
    raw = JSON.parse(stdout);
  } catch (e) {
    throw new StackParseError(`gh stack view --json did not print JSON: ${e.message}`);
  }
  if (typeof raw !== "object" || raw === null || Array.isArray(raw)) {
    throw new StackParseError("expected a JSON object");
  }
  const o = raw;
  if (!Array.isArray(o.branches)) {
    throw new StackParseError("expected branches to be an array");
  }
  const branches = o.branches.map((b, i) => {
    if (typeof b !== "object" || b === null) {
      throw new StackParseError(`branches[${i}] is not an object`);
    }
    const r = b;
    let pr;
    if (r.pr !== void 0 && r.pr !== null) {
      const p = r.pr;
      if (typeof p.number !== "number" || !Number.isInteger(p.number)) {
        throw new StackParseError(`branches[${i}].pr.number is not an integer`);
      }
      const state = str(p.state, `branches[${i}].pr.state`);
      if (!PR_STATES.has(state)) {
        throw new StackParseError(`branches[${i}].pr.state "${state}" is not OPEN, MERGED, or QUEUED`);
      }
      pr = { number: p.number, url: optStr(p.url, "pr.url"), state };
    }
    return {
      name: str(r.name, `branches[${i}].name`),
      head: optStr(r.head, `branches[${i}].head`),
      base: optStr(r.base, `branches[${i}].base`),
      isCurrent: bool(r.isCurrent),
      isMerged: bool(r.isMerged),
      isQueued: bool(r.isQueued),
      needsRebase: bool(r.needsRebase),
      pr
    };
  });
  return {
    trunk: str(o.trunk, "trunk"),
    currentBranch: str(o.currentBranch, "currentBranch"),
    branches
  };
}
async function readStackView(run2, gh, cwd) {
  const r = await run2(gh, ["stack", "view", "--json"], { cwd, quiet: true });
  if (r.code === EXIT.notInStack) {
    return { kind: "not-in-stack", stderr: r.stderr };
  }
  if (r.code === EXIT.ambiguous) {
    return { kind: "ambiguous", stderr: r.stderr };
  }
  if (r.code !== EXIT.ok) {
    return { kind: "error", code: r.code, stderr: r.stderr };
  }
  try {
    return { kind: "ok", view: parseStackView(r.stdout) };
  } catch (e) {
    return { kind: "error", code: r.code, stderr: e.message };
  }
}
function ordinal(n) {
  const mod100 = n % 100;
  if (mod100 >= 11 && mod100 <= 13) {
    return `${n}th`;
  }
  switch (n % 10) {
    case 1:
      return `${n}st`;
    case 2:
      return `${n}nd`;
    case 3:
      return `${n}rd`;
    default:
      return `${n}th`;
  }
}

// src/controller.ts
var RANK = { local: 0, full: 1, network: 2 };
var LINEAR_SECRET = "cairn.linearApiKey";
function timeout(p, ms) {
  return Promise.race([Promise.resolve(p), new Promise((r) => setTimeout(() => r(void 0), ms))]);
}
var StackController = class _StackController {
  constructor(ctx, run2, log2, statusBar) {
    this.ctx = ctx;
    this.run = run2;
    this.log = log2;
    this.statusBar = statusBar;
    this.prs = new PrCache(run2, () => this.gh);
    this.linear = new LinearClient(() => this.linearAuth());
    this.disposables.push(
      workspace.onDidChangeWorkspaceFolders(() => this.resetRepo()),
      workspace.onDidSaveTextDocument(() => this.schedule("local")),
      window.onDidChangeWindowState((s) => s.focused && this.schedule("local")),
      authentication.onDidChangeSessions((e) => {
        if (e.provider.id === "linear") {
          this.linearAuthCache = void 0;
          this.schedule("local");
        }
      }),
      workspace.onDidChangeConfiguration((e) => {
        if (e.affectsConfiguration("cairn")) {
          this.tools = void 0;
          this.schedule("full");
        }
      })
    );
  }
  ctx;
  run;
  log;
  statusBar;
  static viewId = "cairn.stack";
  view;
  repo;
  repoSearched = false;
  tools;
  outcome;
  state = { status: "loading" };
  stack;
  busy = null;
  timer;
  pendingKind = null;
  refreshing = null;
  conflictFiles = /* @__PURE__ */ new Set();
  builderTrunk = null;
  linearBuilder = null;
  linearAuthCache;
  linearAttempted = /* @__PURE__ */ new Set();
  layerCache = /* @__PURE__ */ new Map();
  disposables = [];
  watchers = [];
  prs;
  linear;
  dispose() {
    this.watchers.forEach((d) => d.dispose());
    this.disposables.forEach((d) => d.dispose());
  }
  get gh() {
    return workspace.getConfiguration("cairn").get("ghPath")?.trim() || "gh";
  }
  get remote() {
    return workspace.getConfiguration("cairn").get("remote")?.trim() || "origin";
  }
  // -------------------------------------------------------------------------
  // Webview
  resolveWebviewView(view) {
    this.view = view;
    view.webview.options = {
      enableScripts: true,
      localResourceRoots: [Uri.joinPath(this.ctx.extensionUri, "dist"), Uri.joinPath(this.ctx.extensionUri, "media")]
    };
    view.webview.html = this.html(view.webview);
    view.webview.onDidReceiveMessage((m) => this.onMessage(m).catch((e) => this.fail(e)), void 0, this.disposables);
    view.onDidChangeVisibility(() => view.visible && this.post({ type: "state", state: this.state }), void 0, this.disposables);
  }
  html(webview) {
    const nonce = (0, import_node_crypto2.randomBytes)(16).toString("base64");
    const script = webview.asWebviewUri(Uri.joinPath(this.ctx.extensionUri, "dist", "webview.js"));
    const style = webview.asWebviewUri(Uri.joinPath(this.ctx.extensionUri, "media", "cairn.css"));
    return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src ${webview.cspSource}; img-src ${webview.cspSource} data:; script-src 'nonce-${nonce}';">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="${style}">
<title>Cairn</title>
</head>
<body>
<div id="root"><div class="empty"><p class="loading"><span class="dot pending"></span>Loading stack\u2026</p></div></div>
<script nonce="${nonce}" src="${script}"></script>
</body>
</html>`;
  }
  post(msg) {
    void this.view?.webview.postMessage(msg);
  }
  setState(state) {
    this.state = state;
    this.post({ type: "state", state });
    this.updateStatusBar();
  }
  async onMessage(m) {
    switch (m.type) {
      case "ready":
        this.post({ type: "state", state: this.state });
        return this.schedule("network", 0);
      case "refresh":
        this.tools = void 0;
        return this.schedule("full", 0);
      case "fetch":
        return this.fetch();
      case "checkout":
        return this.checkout(m.branch);
      case "openPr":
        await env.openExternal(Uri.parse(m.url));
        return;
      case "linearOpen":
        await env.openExternal(Uri.parse(m.url));
        return;
      case "openFile":
        return this.openFile(m.branch, m.path);
      case "setDraft":
        return this.setDraft(m.branch, m.title, m.body);
      case "submit":
        return this.submit(m.open);
      case "previewPlan":
        return this.previewPlan(m.order);
      case "applyPlan":
        return this.applyPlan(m.order);
      case "undo":
        return this.undo();
      case "dismissApplied":
        return this.dismissApplied();
      case "publish":
        return this.publish();
      case "continueRebase":
        return this.continueRebase();
      case "abortRebase":
        return this.abortRebase();
      case "resolveFile":
        return this.resolveFile(m.path);
      case "moveEdits":
        return this.moveEdits(m.target);
      case "linearPick":
        return this.linearPick(m.branch);
      case "linearClear":
        return this.linearClear(m.branch);
      case "linearConnect":
        await this.connectLinear();
        return;
      case "switchStack":
        return this.switchStack(m.top);
      case "builderTrunk":
        this.builderTrunk = m.trunk;
        return this.schedule("local", 0);
      case "initStack":
        return this.initStack(m.trunk, m.branches, m.titles, m.issues);
      case "createFromLinear":
        return this.createFromLinear();
      case "cancelLinearBuilder":
        this.linearBuilder = null;
        return this.schedule("local", 0);
      case "openWorktree":
        return this.openWorktree(m.branch);
      case "installGhStack":
        return this.installGhStack();
      case "showOutput":
        this.log.show();
        return;
      case "openSettings":
        await commands.executeCommand("workbench.action.openSettings", "cairn");
        return;
    }
  }
  // -------------------------------------------------------------------------
  // Refresh
  schedule(kind, delay = 200) {
    if (this.pendingKind === null || RANK[kind] > RANK[this.pendingKind]) {
      this.pendingKind = kind;
    }
    clearTimeout(this.timer);
    this.timer = setTimeout(() => void this.flush(), delay);
  }
  async flush() {
    if (this.refreshing) {
      await this.refreshing;
    }
    if (this.busy) {
      return;
    }
    const kind = this.pendingKind;
    this.pendingKind = null;
    if (!kind) {
      return;
    }
    this.refreshing = this.refresh(kind).catch((e) => this.fail(e)).finally(() => this.refreshing = null);
    await this.refreshing;
    if (this.pendingKind) {
      await this.flush();
    }
  }
  resetRepo() {
    this.repo = void 0;
    this.repoSearched = false;
    this.outcome = void 0;
    this.stack = void 0;
    this.prs.clear();
    this.watchers.forEach((d) => d.dispose());
    this.watchers.length = 0;
    this.schedule("network", 0);
  }
  async ensureRepo() {
    if (this.repo || this.repoSearched) {
      return this.repo;
    }
    this.repoSearched = true;
    const folders = (workspace.workspaceFolders ?? []).filter((f) => f.uri.scheme === "file");
    const active = window.activeTextEditor?.document.uri;
    const activeFolder = active ? workspace.getWorkspaceFolder(active) : void 0;
    const ordered = activeFolder ? [activeFolder, ...folders.filter((f) => f !== activeFolder)] : folders;
    for (const f of ordered) {
      try {
        const dirs = await new Git(this.run, f.uri.fsPath).dirs();
        const git = new Git(this.run, dirs.topLevel);
        const key = `cairn.apply:${dirs.commonDir}`;
        const engine = new ApplyEngine(this.run, dirs, {
          get: () => this.ctx.workspaceState.get(key),
          set: (v) => Promise.resolve(this.ctx.workspaceState.update(key, v))
        });
        this.repo = { git, dirs, engine };
        this.watch(dirs);
        return this.repo;
      } catch {
      }
    }
    return void 0;
  }
  watch(dirs) {
    const on = (base, glob, kind) => {
      const w = workspace.createFileSystemWatcher(new RelativePattern(Uri.file(base), glob));
      const fire = () => this.schedule(kind);
      w.onDidChange(fire);
      w.onDidCreate(fire);
      w.onDidDelete(fire);
      this.watchers.push(w);
    };
    on(dirs.gitDir, "HEAD", "full");
    on(dirs.gitDir, "index", "local");
    on(dirs.commonDir, "refs/heads/**", "full");
    on(dirs.commonDir, "packed-refs", "full");
    on(dirs.commonDir, "gh-stack", "full");
    on(dirs.commonDir, "refs/remotes/**", "local");
  }
  async checkTools(cwd) {
    if (this.tools) {
      return this.tools;
    }
    try {
      const r2 = await this.run(this.gh, ["--version"], { cwd, quiet: true });
      if (r2.code !== 0) {
        return "missing-gh";
      }
    } catch {
      return "missing-gh";
    }
    const r = await this.run(this.gh, ["stack", "--version"], { cwd, quiet: true });
    this.tools = r.code === 0 ? "ok" : "missing-gh-stack";
    return this.tools;
  }
  async refresh(kind) {
    const repo2 = await this.ensureRepo();
    if (!repo2) {
      return this.setState({ status: "no-repo" });
    }
    const tools = await this.checkTools(repo2.dirs.topLevel);
    if (tools === "missing-gh") {
      return this.setState({ status: "missing-gh", ghPath: this.gh });
    }
    if (tools === "missing-gh-stack") {
      return this.setState({ status: "missing-gh-stack" });
    }
    const rs = await rebaseState(repo2.dirs);
    if (!this.outcome || kind !== "local" && rs.kind === "none") {
      this.outcome = await readStackView(this.run, this.gh, repo2.dirs.topLevel);
    }
    await this.build(repo2, rs);
    const open = this.openPrNumbers();
    if (kind === "network") {
      await Promise.all([this.prs.refresh(repo2.dirs.topLevel, open, { force: true }), this.resolveLinear(true)]);
      await this.build(repo2, await rebaseState(repo2.dirs));
    } else {
      const before = JSON.stringify(open.map((n) => this.prs.get(n)?.title));
      await Promise.all([this.prs.refresh(repo2.dirs.topLevel, open, { force: false }), this.resolveLinear(false)]);
      if (JSON.stringify(open.map((n) => this.prs.get(n)?.title)) !== before) {
        await this.build(repo2, await rebaseState(repo2.dirs));
      }
    }
  }
  openPrNumbers() {
    if (this.outcome?.kind !== "ok") {
      return [];
    }
    return this.outcome.view.branches.filter((b) => b.pr && b.pr.state !== "MERGED").map((b) => b.pr.number);
  }
  async resolveLinear(force) {
    if (!this.stack || !await this.linearAuth()) {
      return;
    }
    if (force) {
      this.linearAttempted.clear();
    }
    const ids = /* @__PURE__ */ new Set();
    for (const l of this.stack.vm.layers) {
      if (l.linear.kind === "unresolved") {
        ids.add(l.linear.ref);
      } else if (l.linear.kind === "attached" && force) {
        ids.add(l.linear.issue.identifier);
      }
    }
    await Promise.all([...ids].filter((id) => !this.linearAttempted.has(id)).map(async (id) => {
      this.linearAttempted.add(id);
      try {
        await this.linear.issue(id);
      } catch (e) {
        if (e instanceof LinearAuthError) {
          this.linearAuthCache = void 0;
        }
      }
    }));
  }
  async build(repo2, rs) {
    const outcome = this.outcome;
    const common = {
      repoName: path3.basename(repo2.dirs.topLevel),
      lastFetch: this.ctx.workspaceState.get(`cairn.lastFetch:${repo2.dirs.commonDir}`) ?? await lastFetchTime(repo2.dirs),
      op: await this.opVM(repo2, rs),
      linearConnected: !!await this.linearAuth()
    };
    const catalog = await this.catalogStacks(repo2);
    if (outcome.kind === "error") {
      this.stack = void 0;
      return this.setState({ status: "error", code: outcome.code, stderr: outcome.stderr, command: `${this.gh} stack view --json` });
    }
    if (outcome.kind === "not-in-stack" || outcome.kind === "ambiguous") {
      this.stack = void 0;
      const currentBranch = await repo2.git.currentBranch() ?? "HEAD";
      return this.setState({
        status: "no-stack",
        currentBranch,
        ambiguous: outcome.kind === "ambiguous",
        stacks: this.summaries(catalog, currentBranch, null),
        builder: await this.builderVM(repo2, catalog),
        ...common
      });
    }
    const ctx = await this.buildStack(repo2, outcome.view, catalog, rs);
    this.stack = ctx;
    this.setState({
      status: "ready",
      stack: ctx.vm,
      builder: this.linearBuilder ? await this.builderVM(repo2, catalog) : null,
      ...common
    });
  }
  async catalogStacks(repo2) {
    try {
      const snap = await snapshotStackFile(repo2.dirs.commonDir);
      if (!snap.bytes) {
        return [];
      }
      const raw = JSON.parse(snap.bytes.toString());
      return Array.isArray(raw?.stacks) ? listCatalogStacks(raw) : [];
    } catch {
      return [];
    }
  }
  summaries(catalog, currentBranch, view) {
    const viewOrder = view?.branches.map((b) => b.name).join("\n");
    return catalog.filter((s) => s.branches.length > 0).map((s) => {
      const top = s.branches[s.branches.length - 1].branch;
      return {
        key: String(s.index),
        label: s.number ? `Stack #${s.number} \xB7 ${top}` : top,
        top,
        trunk: s.trunk,
        size: s.branches.length,
        active: view ? s.branches.map((b) => b.branch).join("\n") === viewOrder : s.branches.some((b) => b.branch === currentBranch)
      };
    });
  }
  async layerContents(git, base, head, wantBody) {
    const key = `${base}..${head}`;
    let hit = this.layerCache.get(key);
    if (!hit) {
      const [commits, files] = await Promise.all([git.log(base, head).catch(() => []), git.numstat(base, head).catch(() => [])]);
      hit = { commits, files, body: "" };
      if (wantBody && commits.length === 1) {
        hit.body = (await git.commitMessage(commits[0].sha).catch(() => ({ body: "" }))).body;
      }
      if (this.layerCache.size > 500) {
        this.layerCache.clear();
      }
      this.layerCache.set(key, hit);
    }
    return hit;
  }
  async buildStack(repo2, view, catalog, rs) {
    const { git } = repo2;
    const [refs, status] = await Promise.all([git.branchRefs(), git.status()]);
    const trunkRef = refs.has(view.trunk) ? `refs/heads/${view.trunk}` : `${this.remote}/${view.trunk}`;
    const drafts = this.drafts(repo2);
    const layers = [];
    for (let i = 0; i < view.branches.length; i++) {
      const b = view.branches[i];
      const head = b.head ?? refs.get(b.name)?.sha ?? "";
      let parent = view.trunk;
      for (let j = i - 1; j >= 0; j--) {
        if (b.isMerged || !view.branches[j].isMerged) {
          parent = view.branches[j].name;
          break;
        }
      }
      const parentRef = parent === view.trunk ? trunkRef : `refs/heads/${parent}`;
      let rangeBase = b.base ?? "";
      let rangeSource = "recorded";
      if (head && !(b.base && await git.isAncestor(b.base, head))) {
        rangeBase = await git.mergeBase(parentRef, head) ?? b.base ?? head;
        rangeSource = "merge-base";
      }
      const contents = head ? await this.layerContents(git, rangeBase, head, !b.pr) : { commits: [], files: [], body: "" };
      const details = b.pr ? this.prs.get(b.pr.number) : void 0;
      const d = drafts[b.name] ?? {};
      const defaultTitle = details?.title ?? (contents.commits.length === 1 ? contents.commits[0].subject : humanizeBranch(b.name));
      const defaultBody = details?.body ?? contents.body;
      layers.push({
        name: b.name,
        head,
        base: b.base ?? "",
        rangeBase,
        rangeSource,
        parent,
        isCurrent: b.name === view.currentBranch,
        isMerged: b.isMerged,
        isQueued: b.isQueued,
        needsRebase: b.needsRebase,
        pr: b.pr && {
          number: b.pr.number,
          url: b.pr.url ?? details?.url,
          state: b.pr.state,
          title: details?.title,
          body: details?.body,
          isDraft: details?.isDraft,
          reviewDecision: details?.reviewDecision ?? null,
          ci: details?.ci ?? "none",
          comments: details ? details.comments : null,
          baseRefName: details?.baseRefName,
          detailed: !!details
        },
        track: refs.get(b.name)?.track ?? { ahead: 0, behind: 0, gone: false },
        commits: contents.commits,
        files: contents.files,
        additions: contents.files.reduce((n, f) => n + (f.additions ?? 0), 0),
        deletions: contents.files.reduce((n, f) => n + (f.deletions ?? 0), 0),
        draft: {
          title: d.title ?? defaultTitle,
          body: d.body ?? defaultBody,
          titleEdited: d.title !== void 0 && d.title !== defaultTitle,
          bodyEdited: d.body !== void 0 && d.body !== defaultBody
        },
        linear: await this.linearChip(repo2, b.name, head, details?.body)
      });
    }
    const candidates = await this.candidates(repo2, view, catalog, layers, refs);
    const vm = {
      trunk: { name: view.trunk, track: refs.get(view.trunk)?.track ?? { ahead: 0, behind: 0, gone: false } },
      currentBranch: view.currentBranch,
      layers,
      stacks: this.summaries(catalog, view.currentBranch, view),
      candidates: candidates.map(({ name, head, commits }) => ({ name, head, commits })),
      dirty: { tracked: status.tracked, untracked: status.untracked },
      wrongLayer: this.wrongLayer(layers, view.currentBranch, [...status.tracked, ...status.untracked]),
      rebaseInProgress: rs.kind !== "none",
      hasMerged: layers.some((l) => l.isMerged),
      remote: this.remote
    };
    const bottom = layers.find((l) => !l.isMerged) ?? layers[0];
    return { view, vm, trunkTip: bottom?.rangeBase ?? "", candidates };
  }
  async candidates(repo2, view, catalog, layers, refs) {
    const tracked = new Set(catalog.flatMap((s) => s.branches.map((b) => b.branch)));
    view.branches.forEach((b) => tracked.add(b.name));
    let names;
    try {
      names = await repo2.git.localBranchesNotMergedInto(view.trunk);
    } catch {
      return [];
    }
    const out = [];
    for (const name of names.filter((n) => !tracked.has(n) && n !== view.trunk).slice(0, 40)) {
      const head = refs.get(name)?.sha;
      if (!head) {
        continue;
      }
      let base = null;
      for (const l of [...layers].reverse()) {
        if (!l.isMerged && l.head && await repo2.git.isAncestor(l.head, head)) {
          base = l.head;
          break;
        }
      }
      base ??= await repo2.git.mergeBase(view.trunk, head);
      if (!base) {
        continue;
      }
      const count = await repo2.git.raw(["rev-list", "--count", `${base}..${head}`]);
      out.push({ name, head, base, commits: Number(count.stdout.trim()) || 0 });
    }
    return out;
  }
  /** Dirty files that only a lower layer touches suggest the edits belong there. */
  wrongLayer(layers, current, dirty) {
    const idx = layers.findIndex((l) => l.name === current);
    if (idx <= 0 || dirty.length === 0) {
      return null;
    }
    const mine = new Set(layers[idx].files.map((f) => f.path));
    const loose = dirty.filter((p) => !mine.has(p));
    let best = null;
    for (let i = idx - 1; i >= 0; i--) {
      const l = layers[i];
      if (l.isMerged) {
        continue;
      }
      const theirs = new Set(l.files.map((f) => f.path));
      const files = loose.filter((p) => theirs.has(p));
      if (files.length > 0 && (!best || files.length > best.files.length)) {
        best = { layer: l, files };
      }
    }
    return best ? { target: best.layer.name, current, files: best.files } : null;
  }
  async builderVM(repo2, catalog) {
    const { git } = repo2;
    const refs = await git.branchRefs();
    const trunks = [...refs.keys()];
    const def = await git.defaultTrunk() ?? trunks[0] ?? "main";
    const trunk = this.builderTrunk && refs.has(this.builderTrunk) ? this.builderTrunk : def;
    const tracked = new Set(catalog.flatMap((s) => s.branches.map((b) => b.branch)));
    let names = [];
    try {
      names = (await git.localBranchesNotMergedInto(trunk)).filter((n) => !tracked.has(n));
    } catch {
    }
    const candidates = [];
    for (const name of names.slice(0, 60)) {
      const r = await git.raw(["rev-list", "--count", `${trunk}..${name}`]);
      candidates.push({ name, head: refs.get(name)?.sha ?? "", commits: Number(r.stdout.trim()) || 0 });
    }
    const status = await git.status();
    const rs = await rebaseState(repo2.dirs);
    const dirtyReason = rs.kind !== "none" ? "A rebase is in progress. Finish or abort it first." : status.tracked.length ? `You have uncommitted changes in ${status.tracked.length} file${status.tracked.length === 1 ? "" : "s"}. gh stack init checks out the top branch after writing the stack file, so a dirty tree leaves a half-created stack. Commit or stash first.` : void 0;
    return {
      trunks: [trunk, ...trunks.filter((t) => t !== trunk)],
      trunk,
      candidates,
      clean: !dirtyReason,
      dirtyReason,
      linear: this.linearBuilder ?? void 0
    };
  }
  async opVM(repo2, rs) {
    if (this.busy) {
      return { kind: "running", label: this.busy };
    }
    const s = repo2.engine.session;
    if (s?.phase === "running" && rs.kind === "none") {
      return { kind: "conflict", source: "cairn", files: [], allStaged: false, interrupted: true, step: s.next + 1, total: s.steps.length, branch: s.steps[s.next]?.branch };
    }
    if (s?.phase === "conflict" || rs.kind !== "none") {
      const unmerged = await repo2.git.unmergedFiles().catch(() => []);
      unmerged.forEach((f) => this.conflictFiles.add(f));
      const source = s?.phase === "conflict" ? "cairn" : rs.kind === "gh-stack" ? "gh-stack" : "git";
      return {
        kind: "conflict",
        source,
        branch: s?.steps[s.next]?.branch,
        step: s ? s.next + 1 : void 0,
        total: s?.steps.length,
        files: [...this.conflictFiles].map((p) => ({ path: p, staged: !unmerged.includes(p) })),
        allStaged: unmerged.length === 0
      };
    }
    this.conflictFiles.clear();
    if (s?.phase === "applied") {
      const blocker = await repo2.engine.undoBlocker();
      return { kind: "applied", canUndo: !blocker, undoBlockedReason: blocker ?? void 0, published: s.published };
    }
    return { kind: "idle" };
  }
  updateStatusBar() {
    const s = this.state;
    if (s.status !== "ready") {
      this.statusBar.hide();
      return;
    }
    const layers = s.stack.layers;
    const idx = layers.findIndex((l) => l.isCurrent);
    if (idx >= 0) {
      this.statusBar.text = `$(layers) ${layers[idx].name} ${idx + 1}/${layers.length}`;
      this.statusBar.tooltip = `Cairn: you are on ${layers[idx].name}, ${ordinal(idx + 1)} of ${layers.length} layers. Click to check out another layer.`;
    } else {
      this.statusBar.text = `$(layers) ${s.stack.trunk.name} \xB7 ${layers.length} layers`;
      this.statusBar.tooltip = `Cairn: you are on the trunk of a ${layers.length}-layer stack. Click to check out a layer.`;
    }
    this.statusBar.show();
  }
  // -------------------------------------------------------------------------
  // Running commands
  async exec(cmd, args, opts = {}) {
    const repo2 = await this.ensureRepo();
    return this.run(cmd, args, { cwd: repo2.dirs.topLevel, ...opts });
  }
  async withBusy(label, fn) {
    this.busy = label;
    if (this.state.status === "ready" || this.state.status === "no-stack") {
      this.setState({ ...this.state, op: { kind: "running", label } });
    }
    try {
      return await fn();
    } finally {
      this.busy = null;
    }
  }
  /** Shows the exit code meaning and stderr, and points at the output channel. */
  async reportFailure(what, r, gh = true) {
    const meaning = gh ? describeExit(r.code) : `exit code ${r.code}`;
    const detail = r.stderr.trim().split("\n").slice(-6).join("\n");
    const pick = await window.showErrorMessage(`${what} failed (${r.code}: ${meaning}).`, { detail, modal: false }, "Show Output");
    if (pick === "Show Output") {
      this.log.show();
    }
  }
  fail(e) {
    const msg = e instanceof Error ? e.message : String(e);
    this.log.line(`error: ${msg}`);
    void window.showErrorMessage(`Cairn: ${msg}`, "Show Output").then((p) => p && this.log.show());
  }
  async confirm(message, detail, action) {
    const pick = await window.showWarningMessage(message, { modal: true, detail }, action);
    return pick === action;
  }
  /** Why a checkout-class command (checkout, init, add, rebase, sync) must not run now, or null. */
  async gitGuard(what) {
    const repo2 = await this.ensureRepo();
    if (!repo2) {
      return "No git repository is open.";
    }
    if (this.busy) {
      return `${this.busy} is still running.`;
    }
    if (repo2.engine.inFlight) {
      return "A reorder is paused. Continue or abort it first.";
    }
    const rs = await rebaseState(repo2.dirs);
    if (rs.kind !== "none") {
      return rs.kind === "gh-stack" && rs.journal !== "gh-stack-rebase-state" ? `gh stack has an unfinished operation (${rs.journal}). Recover it in a terminal before running ${what}.` : "A rebase is in progress. Continue or abort it first.";
    }
    const st = await repo2.git.status();
    if (st.tracked.length > 0) {
      return `You have uncommitted changes in ${st.tracked.length} file${st.tracked.length === 1 ? "" : "s"}. Commit or stash them before ${what}.`;
    }
    return null;
  }
  async refuse(reason) {
    await window.showWarningMessage(reason);
  }
  // -------------------------------------------------------------------------
  // Navigation
  async checkout(branch) {
    const reason = await this.gitGuard(`checking out ${branch}`);
    if (reason) {
      return this.refuse(reason);
    }
    const isTrunk = this.stack?.view.trunk === branch;
    const args = isTrunk ? ["stack", "trunk"] : ["stack", "checkout", branch];
    const r = await this.withBusy(`Checking out ${branch}`, () => this.exec(this.gh, args));
    if (r.code !== 0) {
      await this.reportFailure(`gh ${args.join(" ")}`, r);
    }
    this.schedule("full", 0);
  }
  async navigate(dir) {
    const reason = await this.gitGuard(`gh stack ${dir}`);
    if (reason) {
      return this.refuse(reason);
    }
    const r = await this.withBusy(`gh stack ${dir}`, () => this.exec(this.gh, ["stack", dir]));
    if (r.code !== 0) {
      await this.reportFailure(`gh stack ${dir}`, r);
    }
    this.schedule("full", 0);
  }
  async pickCheckout() {
    if (!this.stack) {
      await this.refresh("full");
    }
    const s = this.stack;
    if (!s) {
      return this.refuse("This branch is not part of a stack.");
    }
    const items = [...s.vm.layers].reverse().map((l) => ({
      label: `${l.isCurrent ? "$(circle-filled)" : l.isMerged ? "$(check)" : "$(circle-outline)"} ${l.pr?.title ?? l.draft.title}`,
      description: `${l.pr ? `#${l.pr.number} \xB7 ` : ""}${l.name}`,
      branch: l.name
    }));
    items.push({ label: `$(git-branch) ${s.view.trunk}`, description: "trunk", branch: s.view.trunk });
    const pick = await window.showQuickPick(items, { placeHolder: "Check out a layer", matchOnDescription: true });
    if (pick) {
      await this.checkout(pick.branch);
    }
  }
  async switchStack(top) {
    const reason = await this.gitGuard("switching stacks");
    if (reason) {
      return this.refuse(reason);
    }
    const r = await this.withBusy(`Switching to ${top}`, () => this.exec(this.gh, ["stack", "checkout", top]));
    if (r.code !== 0) {
      await this.reportFailure(`gh stack checkout ${top}`, r);
    }
    this.schedule("network", 0);
  }
  async fetch() {
    const repo2 = await this.ensureRepo();
    if (!repo2) {
      return;
    }
    const r = await this.withBusy("Fetching", () => this.exec("git", ["fetch", "--prune"]));
    if (r.code !== 0) {
      await this.reportFailure("git fetch --prune", r, false);
    } else {
      await this.ctx.workspaceState.update(`cairn.lastFetch:${repo2.dirs.commonDir}`, Date.now());
    }
    this.schedule("network", 0);
  }
  async openFile(branch, file) {
    const repo2 = await this.ensureRepo();
    const layer = this.stack?.vm.layers.find((l) => l.name === branch);
    if (!repo2 || !layer) {
      return;
    }
    const uri = Uri.file(path3.join(repo2.dirs.topLevel, file));
    if (layer.isCurrent) {
      await commands.executeCommand("vscode.open", uri);
      return;
    }
    const gitApi = extensions.getExtension("vscode.git")?.exports?.getAPI(1);
    if (!gitApi) {
      await commands.executeCommand("vscode.open", uri);
      return;
    }
    await commands.executeCommand(
      "vscode.diff",
      gitApi.toGitUri(uri, layer.rangeBase),
      gitApi.toGitUri(uri, layer.head),
      `${file} (${branch})`
    );
  }
  // -------------------------------------------------------------------------
  // Titles, bodies, submit
  drafts(repo2) {
    return this.ctx.workspaceState.get(`cairn.drafts:${repo2.dirs.commonDir}`) ?? {};
  }
  async saveDrafts(repo2, drafts) {
    await this.ctx.workspaceState.update(`cairn.drafts:${repo2.dirs.commonDir}`, drafts);
  }
  async setDraft(branch, title, body) {
    const repo2 = await this.ensureRepo();
    if (!repo2) {
      return;
    }
    const drafts = this.drafts(repo2);
    const d = { ...drafts[branch] };
    if (title !== void 0) {
      if (title === null) {
        delete d.title;
      } else {
        d.title = title;
      }
    }
    if (body !== void 0) {
      if (body === null) {
        delete d.body;
      } else {
        d.body = body;
      }
    }
    drafts[branch] = d;
    await this.saveDrafts(repo2, drafts);
    this.schedule("local", 400);
  }
  /** What `Linear:` line a branch's body should carry: url, null for none, undefined to leave it. */
  linearDecision(l) {
    if (l.linear.kind === "attached" && l.linear.source === "workspace") {
      return l.linear.issue.url;
    }
    if (l.linear.kind === "cleared") {
      return extractLinearLink(l.pr?.body)?.kind === "none" ? void 0 : null;
    }
    return void 0;
  }
  async submit(open) {
    const repo2 = await this.ensureRepo();
    const s = this.stack;
    if (!repo2 || !s) {
      return this.refuse("There is no stack to submit.");
    }
    if (this.busy || repo2.engine.inFlight || (await rebaseState(repo2.dirs)).kind !== "none") {
      return this.refuse("Finish the running operation or rebase before submitting.");
    }
    const submitArgs = ["stack", "submit", "--auto", "--remote", this.remote, ...open ? ["--open"] : []];
    const edits = s.vm.layers.filter((l) => !l.isMerged && (l.draft.titleEdited || l.draft.bodyEdited || this.linearDecision(l) !== void 0));
    const detail = [
      `${this.gh} ${submitArgs.join(" ")}`,
      ...edits.map((l) => `${this.gh} pr edit ${l.pr ? `#${l.pr.number}` : `<new PR for ${l.name}>`}${l.draft.titleEdited ? " --title \u2026" : ""} --body \u2026`),
      "",
      open ? "New and existing PRs will be marked ready for review." : "New PRs are created as drafts."
    ].join("\n");
    if (!await this.confirm(open ? "Submit the stack and mark every PR ready for review?" : "Submit the stack?", detail, open ? "Submit and mark ready" : "Submit")) {
      return;
    }
    await this.withBusy("Submitting", async () => {
      await repo2.engine.markPublished();
      const r = await this.exec(this.gh, submitArgs);
      if (r.code !== 0) {
        return this.reportFailure("gh stack submit", r);
      }
      await this.applyEdits(repo2, edits.map((l) => l.name));
    });
    this.schedule("network", 0);
  }
  /** After submit: one `gh pr edit` for each card whose title, body, or Linear line differs from GitHub. */
  async applyEdits(repo2, branches) {
    if (branches.length === 0) {
      return;
    }
    this.outcome = await readStackView(this.run, this.gh, repo2.dirs.topLevel);
    if (this.outcome.kind !== "ok") {
      return;
    }
    const view = this.outcome.view;
    const numbers = view.branches.filter((b) => b.pr).map((b) => b.pr.number);
    await this.prs.refresh(repo2.dirs.topLevel, numbers, { force: true });
    await this.build(repo2, await rebaseState(repo2.dirs));
    const drafts = this.drafts(repo2);
    for (const name of branches) {
      const l = this.stack?.vm.layers.find((x) => x.name === name);
      const actual = l?.pr ? this.prs.get(l.pr.number) : void 0;
      if (!l?.pr || !actual) {
        this.log.line(`skipped gh pr edit for ${name}: no PR found after submit`);
        continue;
      }
      const d = drafts[name] ?? {};
      const title = d.title ?? actual.title;
      const body = withLinearLine(d.body ?? actual.body, this.linearDecision(l));
      if (title === actual.title && body === actual.body) {
        delete drafts[name];
        continue;
      }
      const r = await this.exec(this.gh, ["pr", "edit", String(l.pr.number), "--title", title, "--body", body]);
      if (r.code !== 0) {
        await this.reportFailure(`gh pr edit ${l.pr.number}`, r, false);
        continue;
      }
      delete drafts[name];
    }
    await this.saveDrafts(repo2, drafts);
  }
  // -------------------------------------------------------------------------
  // Reorder
  computePlanFor(order) {
    const s = this.stack;
    if (!s) {
      throw new PlanError("no stack is loaded");
    }
    return computePlan({
      trunk: { name: s.view.trunk, tip: s.trunkTip },
      current: s.vm.layers.map((l) => ({ name: l.name, head: l.head, base: l.rangeBase, isMerged: l.isMerged })),
      candidates: s.candidates.map((c) => ({ name: c.name, head: c.head, base: c.base })),
      proposed: order
    });
  }
  async planBlockers(plan) {
    const repo2 = this.repo;
    const s = this.stack;
    const blockers = [];
    const warnings = [];
    if (this.busy) {
      blockers.push(`${this.busy} is still running.`);
    }
    if (repo2.engine.inFlight) {
      blockers.push("A reorder is already paused. Continue or abort it first.");
    }
    const rs = await rebaseState(repo2.dirs);
    if (rs.kind !== "none") {
      blockers.push("A rebase is already in progress.");
    }
    const st = await repo2.git.status();
    if (st.tracked.length > 0) {
      blockers.push(`The worktree has uncommitted changes in ${st.tracked.length} file${st.tracked.length === 1 ? "" : "s"}. Commit or stash first.`);
    }
    if (s.vm.hasMerged) {
      blockers.push("The stack has merged branches. Run gh stack sync first.");
    }
    const refs = await repo2.git.branchRefs();
    for (const name of /* @__PURE__ */ new Set([...s.vm.layers.map((l) => l.name), ...plan.added])) {
      const t = refs.get(name)?.track;
      if (t && t.behind > 0) {
        blockers.push(`${name} is ${t.behind} commit${t.behind === 1 ? "" : "s"} behind ${t.upstream}. Pull it first: a later push would drop those remote commits.`);
      }
    }
    try {
      const snap = await snapshotStackFile(repo2.dirs.commonDir);
      if (snap.bytes) {
        parseCatalog(snap.bytes);
      }
    } catch (e) {
      blockers.push(e.message);
    }
    const last = this.state.status === "ready" ? this.state.lastFetch : null;
    const tracksRemote = [s.vm.trunk.track, ...s.vm.layers.map((l) => l.track)].some((t) => t.upstream);
    if (tracksRemote && (!last || Date.now() - last > 15 * 6e4)) {
      warnings.push(`Remote-tracking refs were ${last ? `last fetched ${Math.round((Date.now() - last) / 6e4)} minutes ago` : "never fetched"}. Fetch first so the behind-upstream check is current.`);
    }
    if (plan.removed.length) {
      warnings.push(`${plan.removed.join(", ")} will stop being tracked. The branch${plan.removed.length === 1 ? "" : "es"} and any PR stay as they are.`);
    }
    return { blockers, warnings };
  }
  async previewPlan(order) {
    try {
      const plan = this.computePlanFor(order);
      const { blockers, warnings } = await this.planBlockers(plan);
      const vm = {
        steps: describePlan(plan, stackFilePath(this.repo.dirs.commonDir)),
        moved: plan.moved,
        added: plan.added,
        removed: plan.removed,
        noop: plan.noop,
        blockers,
        warnings
      };
      this.post({ type: "plan", order, plan: vm });
    } catch (e) {
      this.post({ type: "plan", order, plan: null, error: e.message });
    }
  }
  async applyPlan(order) {
    const repo2 = this.repo;
    const s = this.stack;
    if (!repo2 || !s) {
      return;
    }
    let plan;
    try {
      plan = this.computePlanFor(order);
    } catch (e) {
      return this.refuse(e.message);
    }
    const { blockers } = await this.planBlockers(plan);
    if (blockers.length) {
      return this.refuse(blockers.join(" "));
    }
    const lines = describePlan(plan, stackFilePath(repo2.dirs.commonDir)).map((l, i) => `${i + 1}. ${l.command}`);
    const ok = await this.confirm(
      "Apply this reorder locally?",
      `${lines.join("\n")}

Every branch SHA and the gh-stack file are snapshotted first, so Undo can restore them. Nothing is pushed.`,
      "Apply"
    );
    if (!ok) {
      return;
    }
    this.conflictFiles.clear();
    const result = await this.withBusy(
      "Applying reorder",
      () => repo2.engine.start(plan, {
        trunk: s.view.trunk,
        trunkTip: s.trunkTip,
        originalOrder: s.view.branches.map((b) => b.name),
        branches: s.vm.layers.map((l) => l.name)
      })
    ).catch((e) => ({ kind: "failed", message: e.message, restored: false }));
    await this.afterApply(result);
  }
  async afterApply(result) {
    if (result.kind === "applied") {
      await this.rekeyAttachments();
      void window.showInformationMessage("Reorder applied locally. Nothing was pushed.", "Publish\u2026", "Undo").then((p) => {
        if (p === "Publish\u2026") {
          void this.publish();
        } else if (p === "Undo") {
          void this.undo();
        }
      });
    } else if (result.kind === "conflict") {
      result.files.forEach((f) => this.conflictFiles.add(f));
      void window.showWarningMessage(`Rebase paused on ${result.branch} (step ${result.step} of ${result.total}): ${result.files.length} conflicted file${result.files.length === 1 ? "" : "s"}. Resolve them in the Cairn panel.`);
    } else {
      this.fail(new Error(`${result.message}${result.restored ? " Every branch and the gh-stack file were restored." : ""}`));
    }
    this.outcome = void 0;
    this.schedule("full", 0);
  }
  /** Linear attachments are keyed by branch and head; carry them to the rewritten heads. */
  async rekeyAttachments() {
    const repo2 = this.repo;
    const all = this.attachments(repo2);
    const refs = await repo2.git.branchRefs();
    let changed = false;
    for (const a of Object.values(all)) {
      const head = refs.get(a.branch)?.sha;
      const key = `${a.branch}@${head}`;
      if (head && head !== a.head && !all[key] && this.latestAttachment(all, a.branch) === a) {
        all[key] = { ...a, head, at: Date.now() };
        changed = true;
      }
    }
    if (changed) {
      await this.saveAttachments(repo2, all);
    }
  }
  async continueRebase() {
    const repo2 = await this.ensureRepo();
    if (!repo2) {
      return;
    }
    if (repo2.engine.session?.phase === "conflict") {
      const result = await this.withBusy("Continuing rebase", () => repo2.engine.continue());
      if (result.kind === "failed" && !result.restored) {
        return this.refuse(result.message);
      }
      return this.afterApply(result);
    }
    const rs = await rebaseState(repo2.dirs);
    const unmerged = await repo2.git.unmergedFiles();
    if (unmerged.length) {
      return this.refuse(`Stage these files first: ${unmerged.join(", ")}`);
    }
    const [cmd, args] = rs.kind === "gh-stack" ? [this.gh, ["stack", "rebase", "--continue"]] : ["git", ["rebase", "--continue"]];
    const r = await this.withBusy("Continuing rebase", () => this.exec(cmd, args, { env: { GIT_EDITOR: "true" } }));
    if (r.code !== 0 && r.code !== EXIT.conflict) {
      await this.reportFailure(`${cmd === "git" ? "git" : "gh"} ${args.join(" ")}`, r, cmd !== "git");
    }
    this.outcome = void 0;
    this.schedule("full", 0);
  }
  async abortRebase() {
    const repo2 = await this.ensureRepo();
    if (!repo2) {
      return;
    }
    if (repo2.engine.session && repo2.engine.session.phase !== "applied") {
      if (!await this.confirm("Abort the reorder?", "Every branch goes back to its snapshot SHA and the gh-stack file to its original bytes.", "Abort and restore")) {
        return;
      }
      await this.withBusy("Restoring snapshot", () => repo2.engine.abort()).catch((e) => this.fail(e));
    } else {
      const rs = await rebaseState(repo2.dirs);
      const [cmd, args] = rs.kind === "gh-stack" ? [this.gh, ["stack", "rebase", "--abort"]] : ["git", ["rebase", "--abort"]];
      if (!await this.confirm("Abort the rebase?", `Runs ${cmd === "git" ? "git" : "gh"} ${args.join(" ")}.`, "Abort")) {
        return;
      }
      const r = await this.withBusy("Aborting rebase", () => this.exec(cmd, args));
      if (r.code !== 0) {
        await this.reportFailure(`${args.join(" ")}`, r, cmd !== "git");
      }
    }
    this.conflictFiles.clear();
    this.outcome = void 0;
    this.schedule("full", 0);
  }
  async resolveFile(file) {
    const repo2 = await this.ensureRepo();
    if (!repo2) {
      return;
    }
    const uri = Uri.file(path3.join(repo2.dirs.topLevel, file));
    try {
      await commands.executeCommand("git.openMergeEditor", uri);
    } catch {
      await commands.executeCommand("vscode.open", uri);
    }
  }
  async undo() {
    const repo2 = await this.ensureRepo();
    if (!repo2) {
      return;
    }
    const blocker = await repo2.engine.undoBlocker();
    if (blocker) {
      return this.refuse(`Cannot undo: ${blocker}.`);
    }
    if (!await this.confirm("Undo the reorder?", "Every branch goes back to the SHA it had before Apply, and the gh-stack file to its original bytes.", "Undo")) {
      return;
    }
    await this.withBusy("Undoing reorder", () => repo2.engine.undo()).catch((e) => this.fail(e));
    this.outcome = void 0;
    this.schedule("full", 0);
  }
  async publish() {
    const repo2 = await this.ensureRepo();
    const s = this.stack;
    if (!repo2 || !s) {
      return;
    }
    if (this.busy || repo2.engine.inFlight || (await rebaseState(repo2.dirs)).kind !== "none") {
      return this.refuse("Finish the running operation or rebase before publishing.");
    }
    const push = ["stack", "push", "--remote", this.remote];
    const submit = ["stack", "submit", "--auto", "--remote", this.remote];
    const edits = s.vm.layers.filter((l) => !l.isMerged && (l.draft.titleEdited || l.draft.bodyEdited || this.linearDecision(l) !== void 0));
    const ok = await this.confirm(
      "Publish the stack?",
      [
        `1. ${this.gh} ${push.join(" ")}`,
        `2. ${this.gh} ${submit.join(" ")}`,
        ...edits.map((l, i) => `${i + 3}. ${this.gh} pr edit ${l.pr ? `#${l.pr.number}` : `<new PR for ${l.name}>`} \u2026`),
        "",
        "Push runs first, so a rejected lease stops before any PR base is retargeted. Undo is no longer available afterwards."
      ].join("\n"),
      "Publish"
    );
    if (!ok) {
      return;
    }
    await this.withBusy("Publishing", async () => {
      await repo2.engine.markPublished();
      const p = await this.exec(this.gh, push);
      if (p.code !== 0) {
        return this.reportFailure("gh stack push", p);
      }
      const r = await this.exec(this.gh, submit);
      if (r.code !== 0) {
        return this.reportFailure("gh stack submit", r);
      }
      await this.applyEdits(repo2, edits.map((l) => l.name));
    });
    this.schedule("network", 0);
  }
  async dismissApplied() {
    await this.repo?.engine.dismiss();
    this.schedule("local", 0);
  }
  // -------------------------------------------------------------------------
  // Wrong-layer edits
  async moveEdits(target) {
    const repo2 = await this.ensureRepo();
    if (!repo2) {
      return;
    }
    if (this.busy || repo2.engine.inFlight || (await rebaseState(repo2.dirs)).kind !== "none") {
      return this.refuse("Finish the running operation or rebase first.");
    }
    const from = await repo2.git.currentBranch();
    const message = `cairn: move edits from ${from} to ${target}`;
    const ok = await this.confirm(
      `Move your uncommitted edits to ${target}?`,
      `1. git stash push --include-untracked -m "${message}"
2. ${this.gh} stack checkout ${target}
3. git stash pop

If the pop conflicts, the stash is kept so nothing is lost.`,
      "Move edits"
    );
    if (!ok) {
      return;
    }
    await this.withBusy(`Moving edits to ${target}`, async () => {
      const stash = await this.exec("git", ["stash", "push", "--include-untracked", "-m", message]);
      if (stash.code !== 0) {
        return this.reportFailure("git stash push", stash, false);
      }
      const co = await this.exec(this.gh, ["stack", "checkout", target]);
      if (co.code !== 0) {
        await this.reportFailure(`gh stack checkout ${target}`, co);
        const back = await this.exec("git", ["stash", "pop"]);
        if (back.code !== 0) {
          await this.reportFailure("git stash pop (restoring your edits on the original branch)", back, false);
        }
        return;
      }
      const pop = await this.exec("git", ["stash", "pop"]);
      if (pop.code !== 0) {
        await this.reportFailure(`git stash pop on ${target} (the stash was kept)`, pop, false);
      }
    });
    this.schedule("full", 0);
  }
  // -------------------------------------------------------------------------
  // Stack creation
  async initStack(trunk, branches, titles, issues) {
    const repo2 = await this.ensureRepo();
    if (!repo2 || branches.length === 0) {
      return;
    }
    const reason = await this.gitGuard("gh stack init");
    if (reason) {
      return this.refuse(reason);
    }
    const current = await repo2.git.currentBranch();
    const catalog = await this.catalogStacks(repo2);
    if (current && catalog.some((s) => s.branches.some((b) => b.branch === current))) {
      const pick = await window.showWarningMessage(
        `gh stack init cannot run from ${current}, which is already a layer of a stack. Check out ${trunk} first?`,
        { modal: true },
        `Check out ${trunk}`
      );
      if (!pick) {
        return;
      }
      const r2 = await this.exec(this.gh, ["stack", "trunk"]);
      if (r2.code !== 0) {
        return this.reportFailure("gh stack trunk", r2);
      }
    }
    const args = ["stack", "init", ...branches, "--base", trunk];
    const ok = await this.confirm(
      `Create a ${branches.length}-layer stack on ${trunk}?`,
      `${this.gh} ${args.join(" ")}

Bottom to top: ${trunk} \u2190 ${branches.join(" \u2190 ")}. Existing branches are adopted; missing ones are created. gh stack checks out ${branches[branches.length - 1]} afterwards.`,
      "Create stack"
    );
    if (!ok) {
      return;
    }
    const r = await this.withBusy("Creating stack", () => this.exec(this.gh, args));
    if (r.code !== 0) {
      await this.reportFailure("gh stack init", r);
      this.schedule("full", 0);
      return;
    }
    if (titles || issues) {
      const drafts = this.drafts(repo2);
      for (const [b, t] of Object.entries(titles ?? {})) {
        drafts[b] = { ...drafts[b], title: t };
      }
      await this.saveDrafts(repo2, drafts);
      const refs = await repo2.git.branchRefs();
      const all = this.attachments(repo2);
      for (const [b, identifier] of Object.entries(issues ?? {})) {
        const issue = this.linear.cached(identifier) ?? this.linearBuilder?.children.find((c) => c.identifier === identifier);
        const head = refs.get(b)?.sha ?? "";
        if (issue) {
          all[`${b}@${head}`] = { branch: b, head, issue, at: Date.now() };
        }
      }
      await this.saveAttachments(repo2, all);
    }
    this.linearBuilder = null;
    this.outcome = void 0;
    this.schedule("network", 0);
  }
  async addBranch() {
    const s = this.stack;
    if (!s) {
      return this.refuse("Open a stack first.");
    }
    const name = await window.showInputBox({ prompt: "New branch name to add on top of the stack", validateInput: (v) => /^\S+$/.test(v) ? null : "Enter a branch name" });
    if (!name) {
      return;
    }
    const reason = await this.gitGuard("gh stack add");
    if (reason) {
      return this.refuse(reason);
    }
    const top = s.vm.layers[s.vm.layers.length - 1];
    await this.withBusy(`Adding ${name}`, async () => {
      if (top && s.view.currentBranch !== top.name) {
        const t = await this.exec(this.gh, ["stack", "top"]);
        if (t.code !== 0) {
          return this.reportFailure("gh stack top", t);
        }
      }
      const r = await this.exec(this.gh, ["stack", "add", name]);
      if (r.code !== 0) {
        await this.reportFailure(`gh stack add ${name}`, r);
      }
    });
    this.outcome = void 0;
    this.schedule("full", 0);
  }
  // -------------------------------------------------------------------------
  // Linear
  async linearAuth() {
    if (this.linearAuthCache !== void 0) {
      return this.linearAuthCache;
    }
    let auth = null;
    try {
      const session = await timeout(authentication.getSession("linear", ["read"], { silent: true }), 2e3);
      if (session) {
        auth = { header: `Bearer ${session.accessToken}`, source: "vscode-session" };
      }
    } catch {
    }
    if (!auth) {
      const key = await this.ctx.secrets.get(LINEAR_SECRET);
      if (key) {
        auth = { header: key, source: "secret" };
      } else if (process.env.LINEAR_API_KEY) {
        auth = { header: process.env.LINEAR_API_KEY, source: "env" };
      }
    }
    this.linearAuthCache = auth;
    return auth;
  }
  async connectLinear() {
    const choice = await window.showQuickPick(
      [
        { label: "$(account) Sign in with Linear", detail: "Uses the Linear authentication provider (install the Linear Connect extension if this fails).", id: "session" },
        { label: "$(key) Paste a Linear personal API key", detail: "Stored in VS Code secret storage. Create one in Linear under Settings \u2192 Security & access.", id: "key" }
      ],
      { placeHolder: "Connect Linear" }
    );
    if (!choice) {
      return false;
    }
    if (choice.id === "session") {
      try {
        const session = await timeout(authentication.getSession("linear", ["read"], { createIfNone: true }), 12e4);
        if (!session) {
          throw new Error("no session");
        }
      } catch {
        void window.showWarningMessage("No Linear sign-in is available in this editor. Paste a personal API key instead.");
        return false;
      }
    } else {
      const key = await window.showInputBox({ prompt: "Linear personal API key", password: true, ignoreFocusOut: true });
      if (!key) {
        return false;
      }
      await this.ctx.secrets.store(LINEAR_SECRET, key.trim());
    }
    this.linearAuthCache = void 0;
    this.linearAttempted.clear();
    this.schedule("network", 0);
    return !!await this.linearAuth();
  }
  async disconnectLinear() {
    await this.ctx.secrets.delete(LINEAR_SECRET);
    this.linearAuthCache = void 0;
    this.schedule("local", 0);
  }
  attachments(repo2) {
    return this.ctx.workspaceState.get(`cairn.linear:${repo2.dirs.commonDir}`) ?? {};
  }
  async saveAttachments(repo2, all) {
    await this.ctx.workspaceState.update(`cairn.linear:${repo2.dirs.commonDir}`, all);
  }
  latestAttachment(all, branch) {
    return Object.values(all).filter((a) => a.branch === branch).sort((a, b) => b.at - a.at)[0];
  }
  async linearChip(repo2, branch, head, body) {
    const all = this.attachments(repo2);
    const att = all[`${branch}@${head}`] ?? this.latestAttachment(all, branch);
    if (att) {
      if (att.issue === null) {
        return { kind: "cleared" };
      }
      return { kind: "attached", issue: this.linear.cached(att.issue.identifier) ?? att.issue, source: "workspace" };
    }
    const link = extractLinearLink(body);
    if (link?.kind === "none") {
      return { kind: "cleared" };
    }
    if (link?.kind === "issue") {
      const issue = this.linear.cached(link.identifier);
      return issue ? { kind: "attached", issue, source: "body" } : { kind: "unresolved", ref: link.identifier, source: "body" };
    }
    return await this.linearAuth() ? { kind: "none" } : { kind: "disconnected" };
  }
  async pickIssue(placeHolder, extra = []) {
    const qp = window.createQuickPick();
    qp.placeholder = placeHolder;
    qp.matchOnDescription = true;
    const toItems = (issues) => [
      ...extra.map((e) => ({ label: e.label, id: e.id, alwaysShow: true })),
      ...issues.map((i) => ({ label: `${i.identifier}  ${i.title}`, description: i.state, issue: i, alwaysShow: true }))
    ];
    let seq = 0;
    const load = async (term) => {
      const mine = ++seq;
      qp.busy = true;
      try {
        const issues = term.trim() ? await this.linear.search(term.trim()) : await this.linear.recent();
        if (mine === seq) {
          qp.items = toItems(issues);
        }
      } catch (e) {
        if (mine === seq) {
          qp.items = [...toItems([]), { label: `$(error) ${e.message}`, alwaysShow: true }];
        }
      } finally {
        if (mine === seq) {
          qp.busy = false;
        }
      }
    };
    let debounce;
    qp.onDidChangeValue((v) => {
      clearTimeout(debounce);
      debounce = setTimeout(() => void load(v), 250);
    });
    void load("");
    return new Promise((resolve2) => {
      qp.onDidAccept(() => {
        const it = qp.selectedItems[0];
        resolve2(it?.issue ?? it?.id);
        qp.hide();
      });
      qp.onDidHide(() => {
        resolve2(void 0);
        qp.dispose();
      });
      qp.show();
    });
  }
  async linearPick(branch) {
    const repo2 = await this.ensureRepo();
    const layer = this.stack?.vm.layers.find((l) => l.name === branch);
    if (!repo2 || !layer) {
      return;
    }
    if (!await this.linearAuth() && !await this.connectLinear()) {
      return;
    }
    const hasIssue = layer.linear.kind === "attached" || layer.linear.kind === "unresolved";
    const picked = await this.pickIssue(`Linear issue for ${branch}`, hasIssue ? [{ label: '$(close) Clear issue (writes "Linear: none" on submit)', id: "clear" }] : []);
    if (picked === void 0) {
      return;
    }
    if (picked === "clear") {
      return this.linearClear(branch);
    }
    if (typeof picked !== "string") {
      const all = this.attachments(repo2);
      all[`${branch}@${layer.head}`] = { branch, head: layer.head, issue: picked, at: Date.now() };
      await this.saveAttachments(repo2, all);
      this.schedule("local", 0);
    }
  }
  async linearClear(branch) {
    const repo2 = await this.ensureRepo();
    const layer = this.stack?.vm.layers.find((l) => l.name === branch);
    if (!repo2 || !layer) {
      return;
    }
    const all = this.attachments(repo2);
    all[`${branch}@${layer.head}`] = { branch, head: layer.head, issue: null, at: Date.now() };
    await this.saveAttachments(repo2, all);
    this.schedule("local", 0);
  }
  async createFromLinear() {
    if (!await this.linearAuth() && !await this.connectLinear()) {
      return;
    }
    const parent = await this.pickIssue("Pick the parent issue whose sub-issues become the layers");
    if (!parent || typeof parent === "string") {
      return;
    }
    let children;
    try {
      children = await this.linear.children(parent.id);
    } catch (e) {
      return this.fail(e);
    }
    if (children.length === 0) {
      return this.refuse(`${parent.identifier} has no sub-issues.`);
    }
    this.linearBuilder = { parent, children };
    await commands.executeCommand(`${_StackController.viewId}.focus`);
    this.schedule("local", 0);
  }
  // -------------------------------------------------------------------------
  // Worktrees and setup
  async openWorktree(branch) {
    const repo2 = await this.ensureRepo();
    if (!repo2) {
      return;
    }
    if (!branch) {
      const picks = this.stack?.vm.layers.filter((l) => !l.isCurrent && !l.isMerged).map((l) => l.name) ?? [];
      branch = await window.showQuickPick(picks, { placeHolder: "Open which layer in a new worktree?" });
      if (!branch) {
        return;
      }
    }
    if ((await rebaseState(repo2.dirs)).kind !== "none" || repo2.engine.inFlight) {
      return this.refuse("A rebase is in progress. Finish or abort it before adding a worktree.");
    }
    if (await repo2.git.currentBranch() === branch) {
      return this.refuse(`${branch} is checked out here. Open a different layer in the new worktree.`);
    }
    const top = repo2.dirs.topLevel;
    const suggested = path3.join(path3.dirname(top), `${path3.basename(top)}.worktrees`, branch.replace(/[^\w.-]+/g, "-"));
    const target = await window.showInputBox({ prompt: `Folder for the ${branch} worktree`, value: suggested, ignoreFocusOut: true });
    if (!target) {
      return;
    }
    const r = await this.withBusy(`Adding worktree for ${branch}`, () => this.exec("git", ["worktree", "add", target, branch]));
    if (r.code !== 0) {
      return this.reportFailure(`git worktree add ${target} ${branch}`, r, false);
    }
    await commands.executeCommand("vscode.openFolder", Uri.file(target), { forceNewWindow: true });
  }
  async installGhStack() {
    const ok = await this.confirm("Install the gh stack extension?", `Runs: ${this.gh} extension install github/gh-stack`, "Install");
    if (!ok) {
      return;
    }
    const cwd = this.repo?.dirs.topLevel ?? workspace.workspaceFolders?.[0]?.uri.fsPath ?? process.cwd();
    const r = await this.run(this.gh, ["extension", "install", "github/gh-stack"], { cwd });
    if (r.code !== 0) {
      await this.reportFailure("gh extension install github/gh-stack", r, false);
    }
    this.tools = void 0;
    this.schedule("network", 0);
  }
  /** Commands that only wrap one gh stack call behind the usual guards. */
  async simple(kind) {
    const s = this.stack;
    switch (kind) {
      case "sync": {
        const reason = await this.gitGuard("gh stack sync");
        if (reason) {
          return this.refuse(reason);
        }
        const args = ["stack", "sync", "--remote", this.remote];
        if (!await this.confirm("Sync the stack?", `${this.gh} ${args.join(" ")}

Fetches, rebases onto the trunk, pushes, and refreshes PR state.`, "Sync")) {
          return;
        }
        const r = await this.withBusy("Syncing", () => this.exec(this.gh, args));
        if (r.code === EXIT.conflict) {
          void window.showWarningMessage('gh stack sync hit a conflict and restored every branch. Run "Cairn: Rebase Upstack" to redo the rebase and resolve it.');
        } else if (r.code !== 0) {
          await this.reportFailure("gh stack sync", r);
        } else if (/Sync aborted/i.test(r.stderr + r.stdout)) {
          void window.showWarningMessage("gh stack sync aborted: the local and GitHub stacks diverged. Nothing changed. See the output channel.", "Show Output").then((p) => p && this.log.show());
        }
        break;
      }
      case "rebaseUpstack": {
        const reason = await this.gitGuard("gh stack rebase");
        if (reason) {
          return this.refuse(reason);
        }
        const args = ["stack", "rebase", "--upstack", "--remote", this.remote];
        if (!await this.confirm("Rebase every layer above this one?", `${this.gh} ${args.join(" ")}`, "Rebase")) {
          return;
        }
        const r = await this.withBusy("Rebasing upstack", () => this.exec(this.gh, args));
        if (r.code === EXIT.conflict) {
          void window.showWarningMessage("gh stack rebase paused on a conflict. Resolve it in the Cairn panel.");
        } else if (r.code !== 0) {
          await this.reportFailure("gh stack rebase --upstack", r);
        }
        break;
      }
      case "unstackLocal": {
        if (!await this.confirm("Stop tracking this stack locally?", `${this.gh} stack unstack --local

Branches, PRs, and the stack on GitHub are kept.`, "Unstack locally")) {
          return;
        }
        const r = await this.withBusy("Unstacking", () => this.exec(this.gh, ["stack", "unstack", "--local"]));
        if (r.code !== 0) {
          await this.reportFailure("gh stack unstack --local", r);
        }
        break;
      }
      case "unstack": {
        if (!await this.confirm("Remove this stack on GitHub and locally?", `${this.gh} stack unstack

The PRs are detached from the stack on GitHub. Branches and PRs are not deleted.`, "Continue")) {
          return;
        }
        if (!await this.confirm("Really detach the PRs on GitHub?", 'This is the second confirmation. Use "Unstack locally" to keep the GitHub stack.', "Detach PRs on GitHub")) {
          return;
        }
        const r = await this.withBusy("Unstacking", () => this.exec(this.gh, ["stack", "unstack"]));
        if (r.code !== 0) {
          await this.reportFailure("gh stack unstack", r);
        }
        break;
      }
      case "merge": {
        if (!s) {
          return this.refuse("Open a stack first.");
        }
        const open = s.vm.layers.filter((l) => l.pr && l.pr.state === "OPEN");
        const target = await window.showQuickPick(
          [...open].reverse().map((l) => ({ label: `#${l.pr.number} ${l.pr.title ?? l.name}`, description: `merges this PR and every unmerged PR below it`, n: l.pr.number })),
          { placeHolder: "Merge up to which PR?" }
        );
        if (!target) {
          return;
        }
        const method = await window.showQuickPick(["--squash", "--merge", "--rebase"], { placeHolder: "Merge method" });
        if (!method) {
          return;
        }
        const args = ["stack", "merge", String(target.n), "--yes", method];
        if (!await this.confirm(`Merge through #${target.n}?`, `${this.gh} ${args.join(" ")}

All-or-nothing: if any PR in the set cannot merge, none do.`, "Merge")) {
          return;
        }
        const r = await this.withBusy("Merging", () => this.exec(this.gh, args));
        if (r.code !== 0) {
          await this.reportFailure("gh stack merge", r);
        }
        break;
      }
    }
    this.outcome = void 0;
    this.schedule("network", 0);
  }
};

// scripts/harness/run.ts
var argv = process.argv.slice(2);
var repo = argv[0];
var flag = (name) => argv.includes(name);
var opt = (name) => {
  const i = argv.indexOf(name);
  return i >= 0 ? argv[i + 1] : void 0;
};
var log = [];
var run = (cmd, args, opts) => new Promise((resolve2, reject) => {
  const child = (0, import_node_child_process.spawn)(cmd, args, { cwd: opts.cwd, env: { ...process.env, GH_PROMPT_DISABLED: "1", NO_COLOR: "1", ...opts.env }, stdio: ["pipe", "pipe", "pipe"] });
  let stdout = "";
  let stderr = "";
  child.stdout.on("data", (d) => stdout += d);
  child.stderr.on("data", (d) => stderr += d);
  child.on("error", reject);
  child.on("close", (code) => {
    const shown = opts.label ?? [cmd, ...args].join(" ");
    log.push(`$ ${shown}  \u2192 exit ${code}${stderr.trim() ? `
    stderr: ${stderr.trim().split("\n").join("\n    stderr: ")}` : ""}`);
    resolve2({ code: code ?? -1, stdout, stderr });
  });
  child.stdin.end(opts.input ?? "");
});
async function main() {
  workspace.workspaceFolders = [{ uri: Uri.file(repo), name: "demo", index: 0 }];
  const ctx = {
    workspaceState: memento(),
    secrets: { get: async () => void 0, store: async () => void 0, delete: async () => void 0 },
    extensionUri: Uri.file(process.cwd()),
    subscriptions: []
  };
  const statusBar = { text: "", tooltip: "", show() {
  }, hide() {
  }, dispose() {
  } };
  const controller = new StackController(ctx, run, { line: (t) => log.push(t), show() {
  } }, statusBar);
  const web = fakeWebviewView();
  controller.resolveWebviewView(web.view);
  const waitFor = async (pred, from, ms = 3e4) => {
    const end = Date.now() + ms;
    while (Date.now() < end) {
      for (let i = from; i < web.posted.length; i++) {
        const m = web.posted[i];
        if (pred(m)) {
          return m;
        }
      }
      await new Promise((r) => setTimeout(r, 50));
    }
    throw new Error("timed out waiting for the host");
  };
  const isState = (status, extra) => (m) => m.type === "state" && m.state.status === status && (!extra || extra(m.state));
  const settle = async () => {
    await new Promise((r) => setTimeout(r, 600));
    const states = web.posted.filter((m) => m.type === "state");
    return states[states.length - 1].state;
  };
  let mark = web.posted.length;
  web.send({ type: "ready" });
  await waitFor(isState("ready"), mark).catch(async () => {
    console.log(JSON.stringify(await settle(), null, 2));
    process.exit(1);
  });
  let state = await settle();
  if (state.status !== "ready") {
    console.log(JSON.stringify(state, null, 2));
    return;
  }
  const show = (s) => {
    if (s.status !== "ready") {
      console.log(`status: ${s.status}`);
      return;
    }
    const layers = s.stack.layers;
    console.log(`statusBar: ${statusBar.text}`);
    console.log(`op: ${JSON.stringify(s.op)}`);
    for (const l of [...layers].reverse()) {
      console.log(`  ${l.isCurrent ? "\u25CF" : l.isMerged ? "\u2713" : "\u25CB"} ${l.draft.title}  [${l.name}]  +${l.additions} \u2212${l.deletions}  range=${l.rangeSource}:${l.rangeBase.slice(0, 7)}  commits=${l.commits.map((c) => c.subject).join(" | ")}  files=${l.files.map((f) => f.path).join(",")}`);
    }
    console.log(`  \u25AA ${s.stack.trunk.name} (trunk) behind=${s.stack.trunk.track.behind}`);
    console.log(`  candidates: ${s.stack.candidates.map((c) => `${c.name}(${c.commits})`).join(", ") || "none"}`);
    console.log(`  dirty: ${JSON.stringify(s.stack.dirty)}  wrongLayer: ${JSON.stringify(s.stack.wrongLayer)}`);
  };
  console.log("--- initial state");
  show(state);
  const out = opt("--state");
  if (out) {
    (0, import_node_fs3.writeFileSync)(out, JSON.stringify(state, null, 2));
  }
  const checkout = opt("--checkout");
  if (checkout) {
    mark = web.posted.length;
    web.send({ type: "checkout", branch: checkout });
    await waitFor(isState("ready", (s) => s.status === "ready" && s.stack.currentBranch === checkout), mark);
    state = await settle();
    console.log(`--- after checkout ${checkout}`);
    show(state);
  }
  const order = opt("--order")?.split(",");
  if (order) {
    mark = web.posted.length;
    web.send({ type: "previewPlan", order });
    const plan = await waitFor((m) => m.type === "plan", mark);
    console.log("--- plan preview");
    console.log(JSON.stringify(plan.plan ?? plan.error, null, 2));
    if (flag("--apply")) {
      mark = web.posted.length;
      web.send({ type: "applyPlan", order });
      await waitFor(isState("ready", (s) => s.status === "ready" && s.op.kind !== "idle" && s.op.kind !== "running"), mark, 6e4);
      state = await settle();
      console.log("--- after apply");
      show(state);
    }
    if (flag("--undo")) {
      mark = web.posted.length;
      web.send({ type: "undo" });
      await waitFor(isState("ready", (s) => s.status === "ready" && s.op.kind === "idle"), mark, 6e4);
      state = await settle();
      console.log("--- after undo");
      show(state);
    }
  }
  console.log("--- prompts the user would have seen");
  for (const p of prompts) {
    console.log(`[${p.kind}] ${p.message}${p.detail ? `
    ${p.detail.split("\n").join("\n    ")}` : ""}`);
  }
  console.log("--- commands run");
  console.log(log.filter((l) => l.startsWith("$ gh") || l.startsWith("$ git rebase") || l.startsWith("$ write") || l.startsWith("$ remove") || l.includes("checkout") || l.includes("update-ref")).join("\n"));
  controller.dispose();
  process.exit(0);
}
main().catch((e) => {
  console.error(e);
  process.exit(1);
});
