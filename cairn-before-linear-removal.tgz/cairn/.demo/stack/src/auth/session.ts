export const sessionTtl = 3600;
